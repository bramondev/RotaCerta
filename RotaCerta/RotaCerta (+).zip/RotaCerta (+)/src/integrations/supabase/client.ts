
import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = "";
const SUPABASE_PUBLISHABLE_KEY = "JhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF6YnJhYXd0ZXd0eHdkZXd6bGdsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzg1NjcwNzQsImV4cCI6MjA1NDE0MzA3NH0.saTTfo_wxD1xIfb1mHjs0P99O2FKcfyJ9QV3Dle0KSM";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);