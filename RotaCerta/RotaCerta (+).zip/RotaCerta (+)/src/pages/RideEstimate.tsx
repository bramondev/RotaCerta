
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const RideEstimate = () => {
  const navigate = useNavigate();
  const [rideType, setRideType] = useState("");
  const [rideValue, setRideValue] = useState("");
  const [waitingTime, setWaitingTime] = useState("");
  const [distance, setDistance] = useState("");
  const [isCancelled, setIsCancelled] = useState(false);
  const [results, setResults] = useState<{
    serviceRate: number;
    waitingRate: number;
    cancellationRate: number;
    total: number;
  } | null>(null);

  const calculateRates = () => {
    const value = parseFloat(rideValue);
    const waiting = parseFloat(waitingTime);
    
    if (!value || !rideType) return;

    const rates = {
      uberx: 0.25,
      ubercomfort: 0.28,
      pop99: 0.20,
      comfort99: 0.23,
    };

    const serviceRate = value * rates[rideType as keyof typeof rates];

    const waitingRate = waiting > 2 ? (waiting - 2) * 0.26 : 0;

    const cancellationRate = isCancelled ? 4.50 : 0;

    const total = serviceRate + waitingRate + cancellationRate;

    setResults({
      serviceRate,
      waitingRate,
      cancellationRate,
      total,
    });
  };

  const clearFields = () => {
    setRideType("");
    setRideValue("");
    setWaitingTime("");
    setDistance("");
    setIsCancelled(false);
    setResults(null);
  };

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => navigate(-1)}
        className="text-primary hover:text-primary/80 hover:bg-transparent mb-4"
      >
        <ArrowLeft className="w-6 h-6" />
      </Button>
      <h1 className="text-2xl font-bold text-primary mb-6">Estimativa de Corrida</h1>

      <div className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="rideType">Tipo de Serviço</Label>
            <Select value={rideType} onValueChange={setRideType}>
              <SelectTrigger className="w-full bg-secondary text-white border-primary">
                <SelectValue placeholder="Selecione o serviço" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="uberx">UberX</SelectItem>
                <SelectItem value="ubercomfort">Uber Comfort</SelectItem>
                <SelectItem value="pop99">99Pop</SelectItem>
                <SelectItem value="comfort99">99Comfort</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="rideValue">Valor da Corrida (R$)</Label>
            <Input
              id="rideValue"
              type="number"
              step="0.01"
              min="0"
              placeholder="Ex: 25.00"
              value={rideValue}
              onChange={(e) => setRideValue(e.target.value)}
              className="bg-secondary text-white border-primary [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="waitingTime">Tempo de Espera (minutos)</Label>
            <Input
              id="waitingTime"
              type="number"
              step="1"
              min="0"
              placeholder="Ex: 4"
              value={waitingTime}
              onChange={(e) => setWaitingTime(e.target.value)}
              className="bg-secondary text-white border-primary [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="distance">Distância (km, opcional)</Label>
            <Input
              id="distance"
              type="number"
              step="0.1"
              min="0"
              placeholder="Ex: 10"
              value={distance}
              onChange={(e) => setDistance(e.target.value)}
              className="bg-secondary text-white border-primary [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="cancelled"
              checked={isCancelled}
              onChange={(e) => setIsCancelled(e.target.checked)}
              className="h-4 w-4 rounded border-primary text-primary focus:ring-primary"
            />
            <Label htmlFor="cancelled">Corrida Cancelada</Label>
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={calculateRates}
              className="flex-1"
            >
              Calcular
            </Button>
            <Button 
              onClick={clearFields}
              variant="outline"
              className="flex-1"
            >
              Limpar
            </Button>
          </div>
        </div>

        {results && (
          <Card className="p-4 bg-secondary border-primary space-y-4">
            <div>
              <h3 className="text-sm text-white/70">Taxa de Serviço</h3>
              <p className="text-lg font-semibold text-primary">
                R$ {results.serviceRate.toFixed(2)}
              </p>
            </div>
            {results.waitingRate > 0 && (
              <div>
                <h3 className="text-sm text-white/70">Taxa de Espera</h3>
                <p className="text-lg font-semibold text-primary">
                  R$ {results.waitingRate.toFixed(2)}
                </p>
              </div>
            )}
            {results.cancellationRate > 0 && (
              <div>
                <h3 className="text-sm text-white/70">Taxa de Cancelamento</h3>
                <p className="text-lg font-semibold text-primary">
                  R$ {results.cancellationRate.toFixed(2)}
                </p>
              </div>
            )}
            <div className="pt-2 border-t border-primary/20">
              <h3 className="text-sm text-white/70">Total de Taxas</h3>
              <p className="text-lg font-semibold text-primary">
                R$ {results.total.toFixed(2)}
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default RideEstimate;
