import { Card } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, Sector, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import NavBar from "@/components/NavBar";
import { FileText, Droplet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { FuelList } from "@/components/statistics/FuelList";
import { DocumentList } from "@/components/statistics/DocumentList";
import { FuelEntry } from "@/types/fuel";
import { useIsMobile } from "@/hooks/use-mobile";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const maintenanceSubtypes = {
  emergency_corrective: { label: "Corretiva Emergencial", color: "#ea384c" },
  planned_corrective: { label: "Corretiva Planejada", color: "#a71d31" },
  predictive_corrective: { label: "Corretiva Preditiva", color: "#800000" },
  scheduled_preventive: { label: "Preventiva Programada", color: "#508542" },
  condition_based_preventive: { label: "Preventiva Baseada em Condição", color: "#90EE90" },
  proactive_preventive: { label: "Preventiva Proativa", color: "#808000" },
};

const Statistics = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [activeIndex, setActiveIndex] = useState<number | undefined>(undefined);
  const [fuelTab, setFuelTab] = useState("all");

  const { data: maintenanceData = [], isLoading: isLoadingMaintenance } = useQuery({
    queryKey: ['maintenance-stats'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('maintenance')
        .select('*');
      if (error) throw error;
      return data;
    },
  });

  const { data: fuelData = [], isLoading: isLoadingFuel } = useQuery({
    queryKey: ['fuel-stats'],
    queryFn: async () => {
      console.log('Fetching fuel entries...');
      const { data, error } = await supabase
        .from('fuel_entries')
        .select('*')
        .order('date', { ascending: false });
      
      if (error) {
        console.error('Error fetching fuel entries:', error);
        throw error;
      }
      
      console.log('Fuel entries fetched:', data);
      return data as FuelEntry[];
    },
  });

  const { data: documents = [], isLoading: isLoadingDocuments } = useQuery({
    queryKey: ['documents'],
    queryFn: async () => {
      console.log('Fetching documents...');
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .order('expiration_date', { ascending: true });
      
      if (error) {
        console.error('Error fetching documents:', error);
        throw error;
      }
      
      console.log('Documents fetched:', data);
      return data;
    },
  });

  const maintenanceStats = {
    totalCost: maintenanceData.reduce((acc, item) => acc + Number(item.cost), 0),
    averageCost: maintenanceData.length > 0 
      ? maintenanceData.reduce((acc, item) => acc + Number(item.cost), 0) / maintenanceData.length 
      : 0,
    totalCount: maintenanceData.length,
  };

  const getFilteredFuelData = (fuelType?: string) => {
    if (!fuelType || fuelType === "all") return fuelData;
    return fuelData.filter(item => item.fuel_type === fuelType);
  };

  const calculateFuelStats = (data: FuelEntry[]) => {
    return {
      totalCost: data.reduce((acc, item) => acc + Number(item.total_cost), 0),
      totalLiters: data.reduce((acc, item) => acc + Number(item.liters), 0),
      averageConsumption: data.length > 0
        ? data.reduce((acc, item) => acc + Number(item.consumption), 0) / data.length
        : 0,
      averagePrice: data.length > 0
        ? data.reduce((acc, item) => acc + Number(item.price_per_liter), 0) / data.length
        : 0,
    };
  };

  const allFuelStats = calculateFuelStats(fuelData);
  const gasolineStats = calculateFuelStats(getFilteredFuelData("gasoline"));
  const ethanolStats = calculateFuelStats(getFilteredFuelData("ethanol"));
  const gasStats = calculateFuelStats(getFilteredFuelData("gas"));
  const dieselStats = calculateFuelStats(getFilteredFuelData("diesel"));

  const fuelConsumptionData = [
    { name: "Gasolina", value: gasolineStats.averageConsumption, color: "#FFA500" },
    { name: "Álcool", value: ethanolStats.averageConsumption, color: "#00CED1" },
    { name: "GNV", value: gasStats.averageConsumption, color: "#9370DB" },
    { name: "Diesel", value: dieselStats.averageConsumption, color: "#2E8B57" }
  ].filter(item => !isNaN(item.value) && item.value > 0);

  const fuelCostData = [
    { name: "Gasolina", value: gasolineStats.totalCost, color: "#FFA500" },
    { name: "Álcool", value: ethanolStats.totalCost, color: "#00CED1" },
    { name: "GNV", value: gasStats.totalCost, color: "#9370DB" },
    { name: "Diesel", value: dieselStats.totalCost, color: "#2E8B57" }
  ].filter(item => item.value > 0);

  const maintenanceTypes = maintenanceData.reduce((acc: { [key: string]: number }, item) => {
    const subtype = item.subtype;
    acc[subtype] = (acc[subtype] || 0) + 1;
    return acc;
  }, {});

  const maintenanceCosts = maintenanceData.reduce((acc: { [key: string]: number }, item) => {
    const subtype = item.subtype;
    acc[subtype] = (acc[subtype] || 0) + Number(item.cost);
    return acc;
  }, {});

  const pieData = Object.entries(maintenanceTypes).map(([subtype, count]) => {
    const cost = maintenanceCosts[subtype] || 0;
    return {
      name: maintenanceSubtypes[subtype as keyof typeof maintenanceSubtypes]?.label || subtype,
      value: count,
      cost: cost,
      costPercentage: (cost / maintenanceStats.totalCost * 100).toFixed(1),
      percentage: (count / maintenanceStats.totalCount * 100).toFixed(1),
      color: maintenanceSubtypes[subtype as keyof typeof maintenanceSubtypes]?.color || "#000000"
    };
  });

  const renderActiveShape = (props: any) => {
    const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload } = props;

    return (
      <g>
        <Sector
          cx={cx}
          cy={cy}
          innerRadius={innerRadius}
          outerRadius={outerRadius + 10}
          startAngle={startAngle}
          endAngle={endAngle}
          fill={fill}
        />
        <Sector
          cx={cx}
          cy={cy}
          startAngle={startAngle}
          endAngle={endAngle}
          innerRadius={outerRadius + 14}
          outerRadius={outerRadius + 16}
          fill={fill}
        />
      </g>
    );
  };

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  const onPieLeave = () => {
    setActiveIndex(undefined);
  };

  const formatTooltipValue = (value: number, name: string, props: any) => {
    const dataItem = pieData.find(item => item.name === name);
    if (dataItem) {
      return [
        `Quantidade: ${value} (${dataItem.percentage}%)`,
        `Custo: R$ ${dataItem.cost.toFixed(2)} (${dataItem.costPercentage}%)`
      ];
    }
    return [`Quantidade: ${value}`];
  };

  const formatFuelTooltip = (value: any, name: string, props: any) => {
    if (name === "value") return [`${value.toFixed(2)} km/L`];
    return [`R$ ${value.toFixed(2)}`];
  };

  const handleAddFuel = () => {
    navigate('/fuel/add');
  };

  const handleEditFuel = (entry: any) => {
    navigate(`/fuel/edit/${entry.id}`);
  };

  const handleAddDocument = () => {
    navigate('/documents/add');
  };

  const handleEditDocument = (doc: any) => {
    navigate(`/documents/edit/${doc.id}`);
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      <div className="bg-black p-4">
        <h1 className="text-foreground text-lg font-semibold">Estatísticas</h1>
      </div>

      <div className="p-4 space-y-6">
        <section>
          <h2 className="text-lg font-semibold mb-4">Manutenção</h2>
          <div className="grid grid-cols-1 gap-4 mb-6">
            <Card className="p-4 bg-secondary">
              <h3 className="text-sm text-foreground/70">Gasto Total</h3>
              <p className="text-2xl font-bold text-primary">
                R$ {maintenanceStats.totalCost.toFixed(2)}
              </p>
            </Card>
            <Card className="p-4 bg-secondary">
              <h3 className="text-sm text-foreground/70">Custo Médio</h3>
              <p className="text-2xl font-bold text-primary">
                R$ {maintenanceStats.averageCost.toFixed(2)}
              </p>
            </Card>
          </div>

          {pieData.length > 0 && (
            <Card className={`p-4 bg-secondary ${isMobile ? 'h-[550px]' : 'h-[450px]'} overflow-hidden`}>
              <h3 className="text-sm text-foreground/70 mb-2">Tipos de Manutenção</h3>
              <p className="text-xs text-foreground/60 mb-4">
                {isLoadingMaintenance ? 'Carregando dados...' : 
                  `Total de ${maintenanceStats.totalCount} manutenções registradas`}
              </p>
              <ResponsiveContainer width="100%" height={isMobile ? 450 : 350}>
                <PieChart>
                  <Pie
                    activeIndex={activeIndex}
                    activeShape={renderActiveShape}
                    data={pieData}
                    cx="50%"
                    cy={isMobile ? "35%" : "50%"}
                    labelLine={false}
                    outerRadius={isMobile ? 100 : 120}
                    fill="#8884d8"
                    dataKey="value"
                    onMouseEnter={onPieEnter}
                    onMouseLeave={onPieLeave}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={formatTooltipValue} />
                  <Legend 
                    layout={isMobile ? "horizontal" : "vertical"}
                    verticalAlign={isMobile ? "bottom" : "middle"}
                    align={isMobile ? "center" : "right"}
                    formatter={(value, entry, index) => {
                      const dataItem = pieData[index];
                      return (
                        <span className="text-xs">
                          {value} ({dataItem.value} - {dataItem.percentage}%)
                        </span>
                      );
                    }}
                    wrapperStyle={{
                      paddingLeft: isMobile ? "0" : "20px",
                      paddingTop: isMobile ? "20px" : "0",
                      fontSize: isMobile ? "10px" : "12px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          )}
        </section>

        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Abastecimento</h2>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={handleAddFuel}
            >
              <Droplet className="h-4 w-4" />
            </Button>
          </div>

          <Tabs defaultValue="all" onValueChange={setFuelTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="all">Todos</TabsTrigger>
              <TabsTrigger value="gasoline">Gasolina</TabsTrigger>
              <TabsTrigger value="ethanol">Álcool</TabsTrigger>
              <TabsTrigger value="gas">GNV</TabsTrigger>
              <TabsTrigger value="diesel">Diesel</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Gasto Total</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {allFuelStats.totalCost.toFixed(2)}
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Consumo Médio</h3>
                  <p className="text-2xl font-bold text-primary">
                    {allFuelStats.averageConsumption.toFixed(1)} km/L
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Total Abastecido</h3>
                  <p className="text-2xl font-bold text-primary">
                    {allFuelStats.totalLiters.toFixed(1)} L
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Preço Médio</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {allFuelStats.averagePrice.toFixed(2)}
                  </p>
                </Card>
              </div>

              {fuelConsumptionData.length > 0 && (
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70 mb-2">Consumo Médio por Combustível</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={fuelConsumptionData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => `${Number(value).toFixed(2)} km/L`} />
                      <Bar dataKey="value" name="Consumo (km/L)">
                        {fuelConsumptionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
              )}

              {fuelCostData.length > 0 && (
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70 mb-2">Gasto por Tipo de Combustível</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={fuelCostData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {fuelCostData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `R$ ${Number(value).toFixed(2)}`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="gasoline" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Gasto Total (Gasolina)</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {gasolineStats.totalCost.toFixed(2)}
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Consumo Médio (Gasolina)</h3>
                  <p className="text-2xl font-bold text-primary">
                    {gasolineStats.averageConsumption.toFixed(1)} km/L
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Total Abastecido (Gasolina)</h3>
                  <p className="text-2xl font-bold text-primary">
                    {gasolineStats.totalLiters.toFixed(1)} L
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Preço Médio (Gasolina)</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {gasolineStats.averagePrice.toFixed(2)}
                  </p>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="ethanol" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Gasto Total (Álcool)</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {ethanolStats.totalCost.toFixed(2)}
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Consumo Médio (Álcool)</h3>
                  <p className="text-2xl font-bold text-primary">
                    {ethanolStats.averageConsumption.toFixed(1)} km/L
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Total Abastecido (Álcool)</h3>
                  <p className="text-2xl font-bold text-primary">
                    {ethanolStats.totalLiters.toFixed(1)} L
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Preço Médio (Álcool)</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {ethanolStats.averagePrice.toFixed(2)}
                  </p>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="gas" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Gasto Total (GNV)</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {gasStats.totalCost.toFixed(2)}
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Consumo Médio (GNV)</h3>
                  <p className="text-2xl font-bold text-primary">
                    {gasStats.averageConsumption.toFixed(1)} km/m³
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Total Abastecido (GNV)</h3>
                  <p className="text-2xl font-bold text-primary">
                    {gasStats.totalLiters.toFixed(1)} m³
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Preço Médio (GNV)</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {gasStats.averagePrice.toFixed(2)}
                  </p>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="diesel" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Gasto Total (Diesel)</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {dieselStats.totalCost.toFixed(2)}
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Consumo Médio (Diesel)</h3>
                  <p className="text-2xl font-bold text-primary">
                    {dieselStats.averageConsumption.toFixed(1)} km/L
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Total Abastecido (Diesel)</h3>
                  <p className="text-2xl font-bold text-primary">
                    {dieselStats.totalLiters.toFixed(1)} L
                  </p>
                </Card>
                <Card className="p-4 bg-secondary">
                  <h3 className="text-sm text-foreground/70">Preço Médio (Diesel)</h3>
                  <p className="text-2xl font-bold text-primary">
                    R$ {dieselStats.averagePrice.toFixed(2)}
                  </p>
                </Card>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-4">
            <FuelList
              isLoading={isLoadingFuel}
              fuelData={getFilteredFuelData(fuelTab)}
              onEdit={handleEditFuel}
            />
          </div>
        </section>

        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Documentos</h2>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={handleAddDocument}
            >
              <FileText className="h-4 w-4" />
            </Button>
          </div>
          
          <DocumentList
            isLoading={isLoadingDocuments}
            documents={documents}
            onEdit={handleEditDocument}
          />
        </section>
      </div>

      <NavBar />
    </div>
  );
};

export default Statistics;
