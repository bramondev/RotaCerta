
import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const formSchema = z.object({
  grossIncome: z.string().transform((val) => Number(val) || 0),
  expenses: z.string().transform((val) => Number(val) || 0),
  taxRegime: z.enum(["mei", "autonomo"]),
});

type FormValues = {
  grossIncome: string;
  expenses: string;
  taxRegime: "mei" | "autonomo";
};

const TaxCalculator = () => {
  const navigate = useNavigate();
  const [results, setResults] = useState<{
    inss: number;
    icms?: number;
    iss?: number;
    irpf?: number;
    total: number;
    suggestion?: string;
  } | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      grossIncome: "0",
      expenses: "0",
      taxRegime: "mei",
    },
  });

  const calculateTaxes = (values: FormValues) => {
    const grossIncome = Number(values.grossIncome) || 0;
    const expenses = Number(values.expenses) || 0;
    const netIncome = grossIncome - expenses;

    if (values.taxRegime === "mei") {
    
      const inss = 75.90;  
      const icms = 1.00;   
      const iss = 5.00;  
      
      let suggestion = "";
      if (grossIncome > 81000) {
        suggestion = "Sua renda anual ultrapassa o limite do MEI (R$ 81.000,00). Considere migrar para ME.";
      }

      setResults({
        inss,
        icms,
        iss,
        total: inss + icms + iss,
        suggestion
      });
    } else {
      
      const inssBase = Math.min(Math.max(netIncome, 1518), 8157.41);
      const inss = inssBase * 0.20;
      
      let irpf = 0;
      if (netIncome > 6000) {
        irpf = netIncome * 0.275 - 869.36;
      } else if (netIncome > 4500) {
        irpf = netIncome * 0.225 - 636.13;
      } else if (netIncome > 3000) {
        irpf = netIncome * 0.150 - 370.40;
      } else if (netIncome > 2000) {
        irpf = netIncome * 0.075 - 158.40;
      }

      let suggestion = "";
      if (netIncome < 3000) {
        suggestion = "Com esta renda, você pode se beneficiar do regime MEI, pagando menos impostos.";
      }

      setResults({
        inss,
        irpf: Math.max(irpf, 0),
        total: inss + Math.max(irpf, 0),
        suggestion
      });
    }
  };

  return (
    <div className="container pb-8">
      <div className="space-y-4 p-4">
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:text-white/80 mb-4"
          onClick={() => navigate('/home')}
        >
          <ArrowLeft className="h-6 w-6" />
        </Button>

        <Card className="bg-black text-white">
          <CardHeader>
            <CardTitle>Calculadora de Impostos</CardTitle>
            <CardDescription className="text-gray-400">
              Calcule seus impostos mensais com base no seu regime tributário
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(calculateTaxes)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="grossIncome"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Ganhos Brutos Mensais</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="Ex: 4000" 
                          className="bg-black border-yellow-500 text-white placeholder:text-gray-500 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription className="text-gray-400">
                        Total recebido no mês
                      </FormDescription>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="expenses"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Despesas Operacionais</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="Ex: 2000" 
                          className="bg-black border-yellow-500 text-white placeholder:text-gray-500 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription className="text-gray-400">
                        Gastos com combustível, manutenção, taxas etc.
                      </FormDescription>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="taxRegime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Regime Tributário</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-black border-yellow-500 text-white">
                            <SelectValue placeholder="Selecione seu regime" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="mei">MEI</SelectItem>
                          <SelectItem value="autonomo">Autônomo</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription className="text-gray-400">
                        Escolha entre MEI ou Autônomo
                      </FormDescription>
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full bg-yellow-500 text-black hover:bg-yellow-600">
                  Calcular
                </Button>
              </form>
            </Form>
          </CardContent>
          {results && (
            <CardFooter className="flex flex-col items-start gap-2 border-t border-gray-800">
              <h3 className="text-lg font-semibold text-white">Resultados:</h3>
              <div className="space-y-2 w-full text-gray-300">
                <div className="flex justify-between">
                  <span>INSS:</span>
                  <span>R$ {results.inss.toFixed(2)}</span>
                </div>
                {results.icms !== undefined && (
                  <div className="flex justify-between">
                    <span>ICMS:</span>
                    <span>R$ {results.icms.toFixed(2)}</span>
                  </div>
                )}
                {results.iss !== undefined && (
                  <div className="flex justify-between">
                    <span>ISS:</span>
                    <span>R$ {results.iss.toFixed(2)}</span>
                  </div>
                )}
                {results.irpf !== undefined && (
                  <div className="flex justify-between">
                    <span>IRPF:</span>
                    <span>R$ {results.irpf.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-white pt-2 border-t border-gray-800">
                  <span>Total de Impostos:</span>
                  <span>R$ {results.total.toFixed(2)}</span>
                </div>
                {results.suggestion && (
                  <div className="mt-4 p-3 bg-yellow-500/10 text-yellow-500 rounded-md text-sm">
                    {results.suggestion}
                  </div>
                )}
              </div>
            </CardFooter>
          )}
        </Card>
      </div>
    </div>
  );
};

export default TaxCalculator;
