
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const FoodDeliveryPricing = () => {
  const navigate = useNavigate();
  const [deliveryType, setDeliveryType] = useState("");
  const [itemValue, setItemValue] = useState("");
  const [results, setResults] = useState<{
    saleValue: number;
    ifoodFee: number;
    netValue: number;
  } | null>(null);

  const calculatePricing = () => {
    const value = parseFloat(itemValue);
    
    if (!value || !deliveryType) return;

    const onlinePaymentFee = 0.032; 
    const anticipationFee = 0.0149; 
    
    const deliveryFee = deliveryType === "own" ? 0.12 : 0.23;
    const totalFeePercentage = deliveryFee + onlinePaymentFee + anticipationFee;
    
    const saleValue = value / (1 - totalFeePercentage);
    const ifoodFee = saleValue * totalFeePercentage;
    const netValue = saleValue - ifoodFee;

    setResults({
      saleValue,
      ifoodFee,
      netValue
    });
  };

  const clearFields = () => {
    setDeliveryType("");
    setItemValue("");
    setResults(null);
  };

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => navigate(-1)}
        className="text-primary hover:text-primary/80 hover:bg-transparent mb-4"
      >
        <ArrowLeft className="w-6 h-6" />
      </Button>
      <h1 className="text-2xl font-bold text-primary mb-6">Calculadora iFood</h1>

      <div className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="deliveryType">Tipo de Entrega</Label>
            <Select value={deliveryType} onValueChange={setDeliveryType}>
              <SelectTrigger className="w-full bg-secondary text-white border-primary">
                <SelectValue placeholder="Selecione o tipo de entrega" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="own">Entrega Própria (12%)</SelectItem>
                <SelectItem value="ifood">Entrega Parceira iFood (23%)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="itemValue">Valor Desejado de Repasse (R$)</Label>
            <Input
              id="itemValue"
              type="number"
              step="0.01"
              min="0"
              placeholder="Ex: 25.00"
              value={itemValue}
              onChange={(e) => setItemValue(e.target.value)}
              className="bg-secondary text-white border-primary [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>

          <div className="flex gap-2">
            <Button 
              onClick={calculatePricing}
              className="flex-1"
            >
              Calcular
            </Button>
            <Button 
              onClick={clearFields}
              variant="outline"
              className="flex-1"
            >
              Limpar
            </Button>
          </div>
        </div>

        {results && (
          <Card className="p-4 bg-secondary border-primary space-y-4">
            <div>
              <h3 className="text-sm text-white/70">Valor de Venda</h3>
              <p className="text-lg font-semibold text-primary">
                R$ {results.saleValue.toFixed(2)}
              </p>
              <p className="text-xs text-white/50">
                Valor que deve ser cadastrado no iFood
              </p>
            </div>
            <div>
              <h3 className="text-sm text-white/70">Taxa do iFood</h3>
              <p className="text-lg font-semibold text-primary">
                R$ {results.ifoodFee.toFixed(2)}
              </p>
              <p className="text-xs text-white/50">
                Total de taxas (Comissão + Pagamento Online + Antecipação)
              </p>
            </div>
            <div className="pt-2 border-t border-primary/20">
              <h3 className="text-sm text-white/70">Repasse Líquido</h3>
              <p className="text-lg font-semibold text-primary">
                R$ {results.netValue.toFixed(2)}
              </p>
              <p className="text-xs text-white/50">
                Valor que você receberá após todas as taxas
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default FoodDeliveryPricing;
