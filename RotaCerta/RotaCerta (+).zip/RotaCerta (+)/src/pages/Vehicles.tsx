import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Search, Plus, Pencil, Trash2, ArrowLeft } from "lucide-react";
import { VehicleForm, VehicleFormData } from "@/components/vehicles/VehicleForm";

const Vehicles = () => {
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<any>(null);
  const [deletingVehicle, setDeletingVehicle] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: vehicles, isLoading } = useQuery({
    queryKey: ["vehicles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vehicles")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const addVehicle = useMutation({
    mutationFn: async (values: VehicleFormData) => {
      console.log("Adding vehicle with values:", values);
      
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      if (!user) throw new Error("No user found");

      const { data, error } = await supabase
        .from("vehicles")
        .insert({
          user_id: user.id,
          type: values.type,
          model: values.model,
          year: parseInt(values.year),
          plate: values.plate.toUpperCase(),
          mileage: parseInt(values.mileage),
          status: values.status,
        })
        .select();

      if (error) {
        console.error("Error in mutation:", error);
        throw error;
      }
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["vehicles"] });
      toast({
        title: "Veículo adicionado com sucesso!",
        className: "bg-black text-white border-0",
      });
      setIsOpen(false);
    },
    onError: (error) => {
      console.error("Error in mutation:", error);
      toast({
        variant: "destructive",
        title: "Erro ao adicionar veículo",
        description: "Verifique os dados e tente novamente",
        className: "bg-black text-white border-0",
      });
    },
  });

  const updateVehicle = useMutation({
    mutationFn: async (values: VehicleFormData) => {
      if (!selectedVehicle) return;

      const { error } = await supabase
        .from("vehicles")
        .update({
          type: values.type,
          model: values.model,
          year: parseInt(values.year),
          plate: values.plate.toUpperCase(),
          mileage: parseInt(values.mileage),
          status: values.status,
        })
        .eq("id", selectedVehicle.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["vehicles"] });
      toast({
        title: "Veículo atualizado com sucesso!",
        className: "bg-black text-white border-0",
      });
      setIsOpen(false);
      setSelectedVehicle(null);
    },
    onError: (error) => {
      console.error("Error updating vehicle:", error);
      toast({
        variant: "destructive",
        title: "Erro ao atualizar veículo",
        description: "Verifique os dados e tente novamente",
        className: "bg-black text-white border-0",
      });
    },
  });

  const deleteVehicle = useMutation({
    mutationFn: async (id: string) => {
      
      const { data: maintenanceRecords, error: maintenanceError } = await supabase
        .from("maintenance")
        .select("id")
        .eq("vehicle_id", id);

      if (maintenanceError) throw maintenanceError;

      if (maintenanceRecords && maintenanceRecords.length > 0) {
        const { error: deleteMaintenanceError } = await supabase
          .from("maintenance")
          .delete()
          .eq("vehicle_id", id);

        if (deleteMaintenanceError) throw deleteMaintenanceError;
      }

      const { error } = await supabase.from("vehicles").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["vehicles"] });
      toast({
        title: "Veículo removido com sucesso!",
        className: "bg-black text-white border-0",
      });
      setDeletingVehicle(null);
    },
    onError: (error) => {
      console.error("Error deleting vehicle:", error);
      toast({
        variant: "destructive",
        title: "Erro ao remover veículo",
        description: "Tente novamente mais tarde",
        className: "bg-black text-white border-0",
      });
    },
  });

  const handleSubmit = (values: VehicleFormData) => {
    console.log("Form submitted with values:", values);
    if (selectedVehicle) {
      updateVehicle.mutate(values);
    } else {
      addVehicle.mutate(values);
    }
  };

  const handleEdit = (vehicle: any) => {
    setSelectedVehicle(vehicle);
    setIsOpen(true);
  };

  const handleDelete = async (vehicle: any) => {
    const { data: maintenanceRecords, error } = await supabase
      .from("maintenance")
      .select("id")
      .eq("vehicle_id", vehicle.id);

    if (error) {
      console.error("Error checking maintenance records:", error);
      toast({
        variant: "destructive",
        title: "Erro ao verificar registros de manutenção",
        description: "Tente novamente mais tarde",
      });
      return;
    }

    setDeletingVehicle({
      ...vehicle,
      hasMaintenanceRecords: maintenanceRecords && maintenanceRecords.length > 0,
    });
  };

  const filteredVehicles = vehicles?.filter(
    (vehicle) =>
      vehicle.model.toLowerCase().includes(search.toLowerCase()) ||
      vehicle.plate.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center mb-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate(-1)}
          className="mr-2"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-semibold">Veículos</h1>
      </div>

      <div className="flex justify-between items-center">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar veículo..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8"
          />
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button
              onClick={() => {
                setSelectedVehicle(null);
              }}
            >
              <Plus className="h-4 w-4 mr-2" />
              Novo Veículo
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md mx-auto">
            <DialogHeader>
              <DialogTitle>
                {selectedVehicle ? "Editar Veículo" : "Novo Veículo"}
              </DialogTitle>
              <DialogDescription>
                Preencha os dados do veículo abaixo
              </DialogDescription>
            </DialogHeader>
            <VehicleForm
              onSubmit={handleSubmit}
              initialData={selectedVehicle ? {
                type: selectedVehicle.type,
                model: selectedVehicle.model,
                year: selectedVehicle.year.toString(),
                plate: selectedVehicle.plate,
                mileage: selectedVehicle.mileage.toString(),
                status: selectedVehicle.status,
              } : undefined}
              submitLabel={selectedVehicle ? "Atualizar" : "Adicionar"}
            />
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      ) : (
        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tipo</TableHead>
                <TableHead>Modelo</TableHead>
                <TableHead>Ano</TableHead>
                <TableHead>Placa</TableHead>
                <TableHead>Quilometragem</TableHead>
                <TableHead>Situação</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredVehicles?.map((vehicle) => (
                <TableRow key={vehicle.id}>
                  <TableCell>
                    {vehicle.type === "car" ? "Carro" : "Moto"}
                  </TableCell>
                  <TableCell>{vehicle.model}</TableCell>
                  <TableCell>{vehicle.year}</TableCell>
                  <TableCell>{vehicle.plate}</TableCell>
                  <TableCell>{vehicle.mileage}</TableCell>
                  <TableCell>
                    <span
                      className={`inline-flex px-2 py-1 rounded-full text-xs font-semibold text-white ${
                        vehicle.status === "regular"
                          ? "bg-green-500"
                          : "bg-red-500"
                      }`}
                    >
                      {vehicle.status === "regular" ? "Regular" : "Irregular"}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(vehicle)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(vehicle)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {filteredVehicles?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center">
                    Nenhum veículo encontrado
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      )}

      <AlertDialog 
        open={!!deletingVehicle} 
        onOpenChange={(open) => !open && setDeletingVehicle(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              {deletingVehicle?.hasMaintenanceRecords ? (
                <>
                  Este veículo possui registros de manutenção associados. 
                  Ao excluir o veículo, todos os registros de manutenção também serão excluídos.
                  Deseja continuar?
                </>
              ) : (
                "Tem certeza que deseja excluir este veículo?"
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => deletingVehicle && deleteVehicle.mutate(deletingVehicle.id)}
            >
              Confirmar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Vehicles;
