import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ThumbsDown, Search, Heart, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useForm } from "react-hook-form";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";

type PostType = 
  | "route_tip"
  | "police_alert"
  | "danger_point"
  | "gas_station"
  | "safety_tip"
  | "food_spot"
  | "other";

interface Post {
  id: string;
  type: PostType;
  state: string;
  city: string;
  location: string;
  date: string;
  time: string;
  ideal_time?: string;
  description: string;
  dislikes: number;
  likes: number;
  user_id: string;
  user_votes?: { [key: string]: 'like' | 'dislike' };
}

const postTypes = {
  route_tip: "Dica de Rota",
  police_alert: "Alerta de Tráfego Policial",
  danger_point: "Ponto de Risco/Perigo",
  gas_station: "Posto de Combustível/Parada",
  safety_tip: "Dica de Segurança",
  food_spot: "Pontos de Alimentação",
  other: "Outros"
};

const states = [
  { value: "AC", label: "Acre" },
  { value: "AL", label: "Alagoas" },
  { value: "AP", label: "Amapá" },
  { value: "AM", label: "Amazonas" },
  { value: "BA", label: "Bahia" },
  { value: "CE", label: "Ceará" },
  { value: "DF", label: "Distrito Federal" },
  { value: "ES", label: "Espírito Santo" },
  { value: "GO", label: "Goiás" },
  { value: "MA", label: "Maranhão" },
  { value: "MT", label: "Mato Grosso" },
  { value: "MS", label: "Mato Grosso do Sul" },
  { value: "MG", label: "Minas Gerais" },
  { value: "PA", label: "Pará" },
  { value: "PB", label: "Paraíba" },
  { value: "PR", label: "Paraná" },
  { value: "PE", label: "Pernambuco" },
  { value: "PI", label: "Piauí" },
  { value: "RJ", label: "Rio de Janeiro" },
  { value: "RN", label: "Rio Grande do Norte" },
  { value: "RS", label: "Rio Grande do Sul" },
  { value: "RO", label: "Rondônia" },
  { value: "RR", label: "Roraima" },
  { value: "SC", label: "Santa Catarina" },
  { value: "SP", label: "São Paulo" },
  { value: "SE", label: "Sergipe" },
  { value: "TO", label: "Tocantins" }
].sort((a, b) => a.label.localeCompare(b.label));

const Community = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();

  const [filters, setFilters] = useState({
    state: "all",
    city: "",
    location: "",
    type: "all" as PostType | "all",
  });
  const [editingPost, setEditingPost] = useState<Post | null>(null);

  const form = useForm({
    defaultValues: {
      type: "route_tip" as PostType,
      state: "",
      city: "",
      location: "",
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().split(':').slice(0, 2).join(':'),
      ideal_time: "",
      description: ""
    }
  });

  const editForm = useForm({
    defaultValues: {
      type: "route_tip" as PostType,
      state: "",
      city: "",
      location: "",
      date: "",
      time: "",
      ideal_time: "",
      description: ""
    }
  });

  const { data: currentUser } = useQuery({
    queryKey: ["current-user"],
    queryFn: async () => {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) throw error;
      return user;
    }
  });

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["community-posts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("community_posts")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Post[];
    }
  });

  const createPostMutation = useMutation({
    mutationFn: async (data: any) => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error("User not authenticated");
      }

      const { error } = await supabase
        .from("community_posts")
        .insert([{ ...data, user_id: user.id }]);
        
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["community-posts"] });
      toast({
        title: "Post criado com sucesso!",
        variant: "default",
      });
      form.reset();
    },
    onError: (error) => {
      console.error("Error creating post:", error);
      toast({
        title: "Erro ao criar post",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const updatePostMutation = useMutation({
    mutationFn: async (data: any) => {
      const { error } = await supabase
        .from("community_posts")
        .update(data)
        .eq("id", editingPost?.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["community-posts"] });
      toast({
        title: "Post atualizado com sucesso!",
        variant: "default",
      });
      setEditingPost(null);
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar post",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const deletePostMutation = useMutation({
    mutationFn: async (postId: string) => {
      const { error } = await supabase
        .from("community_posts")
        .delete()
        .eq("id", postId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["community-posts"] });
      toast({
        title: "Post excluído com sucesso!",
        variant: "default",
      });
    }
  });

  const voteMutation = useMutation({
    mutationFn: async ({ postId, voteType }: { postId: string, voteType: 'like' | 'dislike' }) => {
      const post = posts.find(p => p.id === postId);
      if (!post || !currentUser) return;

      const userVotes = post.user_votes || {};
      const currentUserVote = userVotes[currentUser.id];

      if (currentUserVote) {
        if (currentUserVote === voteType) {
          
          delete userVotes[currentUser.id];
          const updateData = {
            [voteType + 's']: post[voteType + 's'] - 1,
            user_votes: userVotes
          };
          const { error } = await supabase
            .from("community_posts")
            .update(updateData)
            .eq("id", postId);
          if (error) throw error;
        } else {
      
          userVotes[currentUser.id] = voteType;
          const updateData = {
            [voteType + 's']: post[voteType + 's'] + 1,
            [(currentUserVote + 's') as 'likes' | 'dislikes']: post[currentUserVote + 's'] - 1,
            user_votes: userVotes
          };
          const { error } = await supabase
            .from("community_posts")
            .update(updateData)
            .eq("id", postId);
          if (error) throw error;
        }
      } else {
        
        userVotes[currentUser.id] = voteType;
        const { error } = await supabase
          .from("community_posts")
          .update({
            [voteType + 's']: post[voteType + 's'] + 1,
            user_votes: userVotes
          })
          .eq("id", postId);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["community-posts"] });
    }
  });

  const handleSubmit = (data: any) => {
    createPostMutation.mutate(data);
  };

  const handleEditSubmit = (data: any) => {
    updatePostMutation.mutate(data);
  };

  const filteredPosts = posts.filter(post => {
    return (filters.state === "all" || post.state === filters.state) &&
           (!filters.city || post.city.toLowerCase().includes(filters.city.toLowerCase())) &&
           (!filters.location || post.location.toLowerCase().includes(filters.location.toLowerCase())) &&
           (filters.type === "all" || post.type === filters.type);
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate("/home")}>
          <ArrowLeft className="h-6 w-6" />
        </Button>
        <h1 className="text-xl font-bold">Comunidade</h1>
      </div>

      {}
      <div className="space-y-2 mb-6">
        <Select value={filters.type} onValueChange={(value) => setFilters(f => ({ ...f, type: value as PostType | "all" }))}>
          <SelectTrigger>
            <SelectValue placeholder="Filtrar por categoria" />
          </SelectTrigger>
          <SelectContent className="bg-black border-gray-800">
            <ScrollArea className="h-[200px]">
              <SelectItem value="all">Todas as categorias</SelectItem>
              {Object.entries(postTypes).map(([value, label]) => (
                <SelectItem key={value} value={value}>{label}</SelectItem>
              ))}
            </ScrollArea>
          </SelectContent>
        </Select>

        <Select value={filters.state} onValueChange={(value) => setFilters(f => ({ ...f, state: value }))}>
          <SelectTrigger>
            <SelectValue placeholder="Estado" />
          </SelectTrigger>
          <SelectContent className="bg-black border-gray-800">
            <ScrollArea className="h-[200px]">
              <SelectItem value="all">Todos os estados</SelectItem>
              {states.map(state => (
                <SelectItem key={state.value} value={state.value}>{state.label}</SelectItem>
              ))}
            </ScrollArea>
          </SelectContent>
        </Select>

        <Input
          placeholder="Cidade"
          value={filters.city}
          onChange={(e) => setFilters(f => ({ ...f, city: e.target.value }))}
        />

        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-10"
            placeholder="Buscar por trecho/rodovia"
            value={filters.location}
            onChange={(e) => setFilters(f => ({ ...f, location: e.target.value }))}
          />
        </div>
      </div>

      {}
      <div className="space-y-4 mb-20">
        {filteredPosts.map(post => (
          <div key={post.id} className="bg-secondary p-4 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <div>
                <span className="text-sm text-primary">{postTypes[post.type]}</span>
                <h3 className="font-medium">{post.location}</h3>
                <p className="text-sm text-muted-foreground">
                  {post.city}, {post.state}
                </p>
              </div>
              <div className="flex gap-2">
                {currentUser?.id === post.user_id && (
                  <>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => {
                        setEditingPost(post);
                        editForm.reset(post);
                      }}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => deletePostMutation.mutate(post.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </>
                )}
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => voteMutation.mutate({ postId: post.id, voteType: 'like' })}
                  className={post.user_votes?.[currentUser?.id] === 'like' ? 'text-primary' : ''}
                >
                  <Heart className="h-4 w-4" />
                  {post.likes > 0 && (
                    <span className="ml-1 text-xs">{post.likes}</span>
                  )}
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => voteMutation.mutate({ postId: post.id, voteType: 'dislike' })}
                  className={post.user_votes?.[currentUser?.id] === 'dislike' ? 'text-primary' : ''}
                >
                  <ThumbsDown className="h-4 w-4" />
                  {post.dislikes > 0 && (
                    <span className="ml-1 text-xs">{post.dislikes}</span>
                  )}
                </Button>
              </div>
            </div>
            <p className="text-sm line-clamp-2">{post.description}</p>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="link" className="text-xs p-0 h-auto">Ver mais</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{postTypes[post.type]}</DialogTitle>
                </DialogHeader>
                <div className="space-y-2">
                  <p><strong>Local:</strong> {post.location}</p>
                  <p><strong>Cidade:</strong> {post.city}, {post.state}</p>
                  <p><strong>Data:</strong> {post.date} às {post.time}</p>
                  {post.ideal_time && (
                    <p><strong>Horário Ideal:</strong> {post.ideal_time}</p>
                  )}
                  <p className="whitespace-pre-wrap">{post.description}</p>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        ))}
      </div>

      {}
      <Dialog open={!!editingPost} onOpenChange={(open) => !open && setEditingPost(null)}>
        <DialogContent className="max-w-[90vw] w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Editar Postagem</DialogTitle>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditSubmit)} className="space-y-3">
              <div className="grid gap-3">
                <FormField
                  control={editForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Postagem</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-black border-gray-800">
                          <ScrollArea className="h-[200px]">
                            {Object.entries(postTypes).map(([value, label]) => (
                              <SelectItem key={value} value={value}>{label}</SelectItem>
                            ))}
                          </ScrollArea>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    control={editForm.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Estado</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Estado" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-black border-gray-800">
                            <ScrollArea className="h-[200px]">
                              {states.map(state => (
                                <SelectItem key={state.value} value={state.value}>{state.label}</SelectItem>
                              ))}
                            </ScrollArea>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cidade</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={editForm.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rodovia/Trecho</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    control={editForm.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Data</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hora</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={editForm.control}
                  name="ideal_time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Horário Ideal (opcional)</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descrição</FormLabel>
                      <FormControl>
                        <Textarea {...field} className="max-h-32" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button type="submit">Salvar</Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {}
      <Dialog>
        <DialogTrigger asChild>
          <Button className="fixed bottom-4 right-4 rounded-full shadow-lg">
            Nova Postagem
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-[90vw] w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nova Postagem</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-3">
              <div className="grid gap-3">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Postagem</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-black border-gray-800">
                          <ScrollArea className="h-[200px]">
                            {Object.entries(postTypes).map(([value, label]) => (
                              <SelectItem key={value} value={value}>{label}</SelectItem>
                            ))}
                          </ScrollArea>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Estado</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="h-12">
                              <SelectValue placeholder="Selecione o estado" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent 
                            className="bg-black border-gray-800"
                            position={isMobile ? "popper" : "item-aligned"}
                            side={isMobile ? "bottom" : "right"}
                          >
                            <ScrollArea className="h-[300px] w-full p-1">
                              {states.map(({ value, label }) => (
                                <SelectItem 
                                  key={value} 
                                  value={value}
                                  className="cursor-pointer"
                                >
                                  {label}
                                </SelectItem>
                              ))}
                            </ScrollArea>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cidade</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rodovia/Trecho</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-3">
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Data</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="time"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hora</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="ideal_time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Horário Ideal (opcional)</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descrição</FormLabel>
                      <FormControl>
                        <Textarea {...field} className="max-h-32" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button type="submit" className="w-full">Publicar</Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Community;