
import React, { useEffect, useRef } from 'react';
import NavBar from '@/components/NavBar';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const MapNavigation = () => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
  
    const loadMapboxScript = () => {
      const mapboxScript = document.createElement('script');
      mapboxScript.src = 'https://api.mapbox.com/mapbox-gl-js/v1.12.0/mapbox-gl.js';
      mapboxScript.async = true;
      
      mapboxScript.onload = () => {
      
        window.mapboxgl.accessToken = "pk.eyJ1IjoibWF0enR1cmluZyIsImEiOiJjbTdwZmZyaWowbTBwMm1wdXBkNnViN2NpIn0.dxYMa0NIsLmdeMl-mKIP_Q";
        
        const directionsScript = document.createElement('script');
        directionsScript.src = 'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.1.0/mapbox-gl-directions.js';
        directionsScript.async = true;
        
        directionsScript.onload = () => {
          initializeMap();
        };
        
        document.head.appendChild(directionsScript);
        
        const mapboxCss = document.createElement('link');
        mapboxCss.rel = 'stylesheet';
        mapboxCss.href = 'https://api.mapbox.com/mapbox-gl-js/v1.12.0/mapbox-gl.css';
        document.head.appendChild(mapboxCss);
        
        const directionsCss = document.createElement('link');
        directionsCss.rel = 'stylesheet';
        directionsCss.href = 'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.1.0/mapbox-gl-directions.css';
        document.head.appendChild(directionsCss);
      };
      
      document.head.appendChild(mapboxScript);
    };

    loadMapboxScript();

    return () => {
     
      const scripts = document.querySelectorAll('script[src*="mapbox"]');
      const links = document.querySelectorAll('link[href*="mapbox"]');
      
      scripts.forEach(script => script.remove());
      links.forEach(link => link.remove());
    };
  }, []);

  const initializeMap = () => {
   
    const mapboxgl = window.mapboxgl;
    
    const MapboxDirections = window.MapboxDirections;
    
    if (!mapboxgl || !MapboxDirections) return;

    const setupMap = (center: [number, number]) => {
      if (!mapContainerRef.current) return;
      
      const map = new mapboxgl.Map({
        container: mapContainerRef.current,
        style: "mapbox://styles/mapbox/streets-v11",
        center: center,
        zoom: 15,
        language: "pt"
      });

      const nav = new mapboxgl.NavigationControl();
      map.addControl(nav);

      const directions = new MapboxDirections({
        accessToken: mapboxgl.accessToken,
        language: "pt"
      });

      map.addControl(directions, "top-left");
    };

    const successLocation = (position: GeolocationPosition) => {
      setupMap([position.coords.longitude, position.coords.latitude]);
    };

    const errorLocation = () => {
      
      setupMap([-46.6333, -23.5505]);
    };

    navigator.geolocation.getCurrentPosition(successLocation, errorLocation, {
      enableHighAccuracy: true
    });
  };

  return (
    <div className="flex flex-col h-screen">
      <div className="bg-background p-4 border-b flex items-center">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="mr-2">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold">RotaCerta Navegação</h1>
      </div>
      
      <div ref={mapContainerRef} className="flex-1 w-full" />
      
      <NavBar />
    </div>
  );
};

export default MapNavigation;
