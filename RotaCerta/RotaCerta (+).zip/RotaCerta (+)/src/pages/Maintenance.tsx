import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { format, isAfter } from "date-fns";
import NavBar from "@/components/NavBar";
import { Button } from "@/components/ui/button";
import { MaintenanceDialog } from "@/components/maintenance/MaintenanceDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const maintenanceSubtypes = {
  emergency_corrective: { label: "Corretiva Emergencial", color: "#ea384c" },
  planned_corrective: { label: "Corretiva Planejada", color: "#a71d31" },
  predictive_corrective: { label: "Corretiva Preditiva", color: "#800000" },
  scheduled_preventive: { label: "Preventiva Programada", color: "#508542" },
  condition_based_preventive: { label: "Preventiva Baseada em Condição", color: "#90EE90" },
  proactive_preventive: { label: "Preventiva Proativa", color: "#808000" },
};

interface MaintenanceRecord {
  id: string;
  vehicle_id: string;
  user_id: string;
  category: "corrective" | "preventive";
  subtype: "emergency_corrective" | "planned_corrective" | "predictive_corrective" | "scheduled_preventive" | "condition_based_preventive" | "proactive_preventive";
  description: string | null;
  cost: number;
  mileage: number;
  date: string;
  created_at: string;
  updated_at: string;
  type: string | null;
  is_future: boolean;
  vehicles: {
    model: string;
    plate: string;
  };
}

const Maintenance = () => {
  const [open, setOpen] = useState(false);
  const [editingMaintenance, setEditingMaintenance] = useState<MaintenanceRecord | null>(null);
  const [deletingMaintenanceId, setDeletingMaintenanceId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: maintenanceRecords, isLoading } = useQuery({
    queryKey: ["maintenance"],
    queryFn: async () => {
      const { data: maintenance, error } = await supabase
        .from("maintenance")
        .select(`
          *,
          vehicles (
            model,
            plate
          )
        `)
        .order("date", { ascending: false });

      if (error) throw error;
      return maintenance as MaintenanceRecord[];
    },
  });

  const completedMaintenance = maintenanceRecords?.filter(record => !record.is_future) || [];
  const futureMaintenance = maintenanceRecords?.filter(record => record.is_future) || [];
  
  const sortedFutureMaintenance = [...futureMaintenance].sort((a, b) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  const nextMaintenance = sortedFutureMaintenance.length > 0 ? sortedFutureMaintenance[0] : null;
  
  const latestMaintenance = completedMaintenance.length > 0 ? completedMaintenance[0] : null;
  
  const totalMileage = completedMaintenance.reduce((sum, record) => sum + record.mileage, 0);
  
  const totalCost = completedMaintenance.reduce((sum, record) => sum + record.cost, 0) || 0;

  const handleDelete = async () => {
    try {
      const { error } = await supabase
        .from("maintenance")
        .delete()
        .eq("id", deletingMaintenanceId);

      if (error) throw error;

      toast({
        title: "Manutenção excluída com sucesso!",
      });

      queryClient.invalidateQueries({ queryKey: ["maintenance"] });
    } catch (error) {
      console.error("Erro ao excluir manutenção:", error);
      toast({
        variant: "destructive",
        title: "Erro ao excluir manutenção",
        description: "Tente novamente mais tarde",
      });
    } finally {
      setDeletingMaintenanceId(null);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-24">
      <div className="flex justify-between items-center p-4 border-b border-primary/20">
        <h1 className="text-2xl font-bold text-foreground">Manutenção</h1>
        <Button 
          variant="default" 
          className="rounded-full"
          onClick={() => {
            setEditingMaintenance(null);
            setOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" /> Nova Manutenção
        </Button>
      </div>

      <main className="p-4">
        <div className="space-y-6">
          <section className="grid grid-cols-2 gap-4">
            <div className="bg-secondary p-4 rounded-lg">
              <h3 className="text-sm text-foreground/70">Quilometragem Total</h3>
              <p className="text-xl font-bold text-primary">
                {totalMileage} km
              </p>
            </div>
            <div className="bg-secondary p-4 rounded-lg">
              <h3 className="text-sm text-foreground/70">Próxima Manutenção</h3>
              {nextMaintenance ? (
                <div>
                  <p className="text-xl font-bold text-primary">
                    {format(new Date(nextMaintenance.date), "dd/MM/yyyy")}
                  </p>
                  <p className="text-xs text-foreground/70 mt-1">
                    {maintenanceSubtypes[nextMaintenance.subtype]?.label || ""}
                  </p>
                </div>
              ) : (
                <p className="text-xl font-bold text-primary">Não agendada</p>
              )}
            </div>
            <div className="bg-secondary p-4 rounded-lg">
              <h3 className="text-sm text-foreground/70">Última Manutenção</h3>
              <p className="text-xl font-bold text-primary">
                {latestMaintenance
                  ? format(new Date(latestMaintenance.date), "dd/MM/yyyy")
                  : "Nenhuma"}
              </p>
            </div>
            <div className="bg-secondary p-4 rounded-lg">
              <h3 className="text-sm text-foreground/70">Custo Total</h3>
              <p className="text-xl font-bold text-primary">
                R$ {totalCost.toFixed(2)}
              </p>
            </div>
          </section>

          {futureMaintenance.length > 0 && (
            <section>
              <h2 className="text-lg font-semibold mb-4">Manutenções Futuras</h2>
              <div className="space-y-4">
                {sortedFutureMaintenance.map((record) => (
                  <div
                    key={record.id}
                    className="bg-secondary p-4 rounded-lg space-y-2 border-l-4"
                    style={{ borderLeftColor: maintenanceSubtypes[record.subtype].color }}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">
                          {maintenanceSubtypes[record.subtype].label}
                        </h3>
                        <p className="text-sm text-foreground/70">
                          {record.vehicles.model} - {record.vehicles.plate}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setEditingMaintenance(record);
                            setOpen(true);
                          }}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeletingMaintenanceId(record.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    {record.description && (
                      <p className="text-sm">{record.description}</p>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="font-medium text-primary">
                        {format(new Date(record.date), "dd/MM/yyyy")}
                      </span>
                      <span>{record.mileage} km</span>
                      <span>R$ {record.cost.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            </div>
          ) : completedMaintenance.length === 0 ? (
            <div className="text-center text-foreground/70 py-8">
              Nenhuma manutenção registrada
            </div>
          ) : (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold mb-4">Histórico Atual</h2>
              {completedMaintenance.map((record) => (
                <div
                  key={record.id}
                  className="bg-secondary p-4 rounded-lg space-y-2"
                  style={{ borderLeft: `4px solid ${maintenanceSubtypes[record.subtype].color}` }}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold">
                        {maintenanceSubtypes[record.subtype].label}
                      </h3>
                      <p className="text-sm text-foreground/70">
                        {record.vehicles.model} - {record.vehicles.plate}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setEditingMaintenance(record);
                          setOpen(true);
                        }}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeletingMaintenanceId(record.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  {record.description && (
                    <p className="text-sm">{record.description}</p>
                  )}
                  <div className="flex justify-between text-sm">
                    <span>
                      {format(new Date(record.date), "dd/MM/yyyy")}
                    </span>
                    <span>{record.mileage} km</span>
                    <span>R$ {record.cost.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <MaintenanceDialog
        open={open}
        onOpenChange={setOpen}
        maintenance={editingMaintenance}
      />

      <AlertDialog
        open={!!deletingMaintenanceId}
        onOpenChange={(open) => !open && setDeletingMaintenanceId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta manutenção? Esta ação não pode
              ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>
              Confirmar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <NavBar />
    </div>
  );
};

export default Maintenance;
