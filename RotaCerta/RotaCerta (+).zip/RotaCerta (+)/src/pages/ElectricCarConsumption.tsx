
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useState } from "react";

const ElectricCarConsumption = () => {
  const navigate = useNavigate();
  const [batteryCapacity, setBatteryCapacity] = useState("");
  const [consumption, setConsumption] = useState("");
  const [electricityCost, setElectricityCost] = useState("");
  const [results, setResults] = useState<{
    range: number;
    totalCost: number;
    costPerKm: number;
  } | null>(null);

  const calculateConsumption = () => {
    const capacity = parseFloat(batteryCapacity);
    const avgConsumption = parseFloat(consumption);
    const cost = parseFloat(electricityCost);

    if (capacity && avgConsumption && cost) {
      const range = (capacity / avgConsumption) * 100;
      const totalCost = capacity * cost;
      const costPerKm = totalCost / range;

      setResults({
        range,
        totalCost,
        costPerKm,
      });
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => navigate(-1)}
        className="text-primary hover:text-primary/80 hover:bg-transparent mb-4"
      >
        <ArrowLeft className="w-6 h-6" />
      </Button>
      <h1 className="text-2xl font-bold text-primary mb-6">Calculadora de Consumo - Carros Elétricos</h1>

      <div className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="battery" className="text-white">Capacidade da bateria (kWh)</Label>
            <Input
              id="battery"
              type="number"
              step="0.1"
              min="0"
              placeholder="Ex: 50"
              value={batteryCapacity}
              onChange={(e) => setBatteryCapacity(e.target.value)}
              className="bg-secondary text-white border-primary [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="consumption" className="text-white">Consumo médio (kWh/100km)</Label>
            <Input
              id="consumption"
              type="number"
              step="0.1"
              min="0"
              placeholder="Ex: 15"
              value={consumption}
              onChange={(e) => setConsumption(e.target.value)}
              className="bg-secondary text-white border-primary [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cost" className="text-white">Custo da eletricidade (R$/kWh)</Label>
            <Input
              id="cost"
              type="number"
              step="0.01"
              min="0"
              placeholder="Ex: 0.70"
              value={electricityCost}
              onChange={(e) => setElectricityCost(e.target.value)}
              className="bg-secondary text-white border-primary [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
            />
          </div>

          <Button 
            onClick={calculateConsumption}
            className="w-full"
          >
            Calcular
          </Button>
        </div>

        {results && (
          <Card className="p-4 bg-secondary border-primary space-y-4">
            <div>
              <h3 className="text-sm text-white/70">Autonomia estimada</h3>
              <p className="text-lg font-semibold text-primary">
                {results.range.toFixed(1)} km
              </p>
            </div>
            <div>
              <h3 className="text-sm text-white/70">Custo de recarga</h3>
              <p className="text-lg font-semibold text-primary">
                R$ {results.totalCost.toFixed(2)}
              </p>
            </div>
            <div>
              <h3 className="text-sm text-white/70">Custo por km</h3>
              <p className="text-lg font-semibold text-primary">
                R$ {results.costPerKm.toFixed(3)}
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default ElectricCarConsumption;
