import { useState } from "react";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, PlusCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import CreateGoalForm from "@/components/goals/CreateGoalForm";
import EditGoalForm from "@/components/goals/EditGoalForm";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import NavBar from "@/components/NavBar";
import { useToast } from "@/components/ui/use-toast";

type Goal = {
  id: string;
  name: string;
  category: string;
  target_amount: number;
  current_amount: number;
  deadline: string;
};

const Goals = () => {
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isAddValueOpen, setIsAddValueOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: goals, isLoading } = useQuery({
    queryKey: ["goals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("goals")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Goal[];
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (goalId: string) => {
      const { error } = await supabase.from("goals").delete().eq("id", goalId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["goals"] });
      toast({
        title: "Meta excluída com sucesso!",
        variant: "default",
      });
      setIsDeleteOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Erro ao excluir meta",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addValueMutation = useMutation({
    mutationFn: async ({ goalId, amount }: { goalId: string; amount: number }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { error: transactionError } = await supabase
        .from("goal_transactions")
        .insert({
          goal_id: goalId,
          user_id: user.id,
          amount: amount,
        });

      if (transactionError) throw transactionError;

      const { error: updateError } = await supabase
        .from("goals")
        .update({
          current_amount: selectedGoal!.current_amount + amount,
        })
        .eq("id", goalId);

      if (updateError) throw updateError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["goals"] });
      toast({
        title: "Valor adicionado com sucesso!",
        variant: "default",
      });
      setIsAddValueOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Erro ao adicionar valor",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const calculateDaysRemaining = (deadline: string) => {
    const days = Math.ceil(
      (new Date(deadline).getTime() - new Date().getTime()) / (1000 * 3600 * 24)
    );
    return days > 0 ? `Faltam ${days} dias` : "Meta vencida";
  };

  const calculateProgress = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const handleDelete = (goal: Goal) => {
    setSelectedGoal(goal);
    setIsDeleteOpen(true);
  };

  const handleEdit = (goal: Goal) => {
    setSelectedGoal(goal);
    setIsEditOpen(true);
  };

  const handleAddValue = (goal: Goal) => {
    setSelectedGoal(goal);
    setIsAddValueOpen(true);
  };

  const confirmAddValue = (amount: number) => {
    if (selectedGoal) {
      addValueMutation.mutate({ goalId: selectedGoal.id, amount });
    }
  };

  const confirmDelete = () => {
    if (selectedGoal) {
      deleteMutation.mutate(selectedGoal.id);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 pb-20">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-white">Minhas Metas</h1>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button variant="default" className="rounded-full">
              <Plus className="mr-2 h-4 w-4" /> Criar Meta
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-black border border-primary">
            <DialogHeader>
              <DialogTitle className="text-white">Nova Meta</DialogTitle>
            </DialogHeader>
            <CreateGoalForm onSuccess={() => setIsCreateOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {goals?.map((goal) => (
          <div
            key={goal.id}
            className="bg-black border border-primary rounded-lg p-4 shadow-lg"
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="text-white font-bold">{goal.name}</h3>
                <p className="text-gray-400 text-sm">{goal.category}</p>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => handleAddValue(goal)}
                >
                  <PlusCircle className="h-4 w-4 text-green-500" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => handleEdit(goal)}
                >
                  <Pencil className="h-4 w-4 text-primary" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => handleDelete(goal)}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              </div>
            </div>

            <div className="mb-2">
              <Progress
                value={calculateProgress(goal.current_amount, goal.target_amount)}
                className="h-2"
              />
              <p className="text-sm text-primary mt-1">
                {calculateProgress(goal.current_amount, goal.target_amount).toFixed(1)}% concluído
              </p>
            </div>

            <div className="flex justify-between text-sm mb-2">
              <span className="text-white">
                R$ {goal.current_amount.toFixed(2)}
              </span>
              <span className="text-white">
                R$ {goal.target_amount.toFixed(2)}
              </span>
            </div>

            <p className="text-primary text-sm">
              {calculateDaysRemaining(goal.deadline)}
            </p>
          </div>
        ))}
      </div>

      {}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="bg-black border border-primary">
          <DialogHeader>
            <DialogTitle className="text-white">Editar Meta</DialogTitle>
          </DialogHeader>
          {selectedGoal && (
            <EditGoalForm
              goal={selectedGoal}
              onSuccess={() => setIsEditOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      {}
      <Dialog open={isAddValueOpen} onOpenChange={setIsAddValueOpen}>
        <DialogContent className="bg-black border border-primary">
          <DialogHeader>
            <DialogTitle className="text-white">Adicionar Valor à Meta</DialogTitle>
          </DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const amount = Number(formData.get('amount'));
            if (amount > 0) {
              confirmAddValue(amount);
            }
          }} className="space-y-4">
            <div>
              <label htmlFor="amount" className="text-white block mb-2">Valor</label>
              <input
                type="number"
                id="amount"
                name="amount"
                step="0.01"
                min="0.01"
                required
                className="w-full p-2 rounded bg-black text-white border border-primary [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
              />
            </div>
            <Button type="submit" className="w-full">
              Adicionar
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent className="bg-black border border-primary">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white">Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta meta? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>
              Confirmar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <NavBar />
    </div>
  );
};

export default Goals;