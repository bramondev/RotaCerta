import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { 
  Plus, DollarSign, Edit, Trash, ArrowUp, ArrowDown, Wallet, Car, Info, Globe,
  Building, Truck, FileText, Zap, Wrench, Calculator, PlugZap, Settings, Users, Map
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { Database } from "@/integrations/supabase/types";
import NavBar from "@/components/NavBar";
import { useNavigate } from "react-router-dom";
import FinanceBot from "@/components/FinanceBot";
import { Bike, Circle, CircleDashed, Droplet, Link, StopCircle, Wind } from "lucide-react";

type TransactionType = Database["public"]["Enums"]["transaction_type"];

const Home = () => {
  const [isAddingTransaction, setIsAddingTransaction] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<any>(null);
  const [deletingTransaction, setDeletingTransaction] = useState<string | null>(null);
  const [showMaintenanceTips, setShowMaintenanceTips] = useState(false);
  const [showBankNumbers, setShowBankNumbers] = useState(false);
  const [showTowingNumbers, setShowTowingNumbers] = useState(false);
  const [welcomeMessage, setWelcomeMessage] = useState("");
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [activeMaintenanceTab, setActiveMaintenanceTab] = useState("cars");
  const [activeAccordions, setActiveAccordions] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const getTimeBasedMessage = () => {
      const hour = new Date().getHours();
      let messages = [];
      
      if (hour >= 5 && hour < 12) {
        messages = [
          "Bom dia, campeão! Vamos colocar a roda para girar e conquistar o dia. Que as rotas sejam rápidas e as metas alcançadas!",
          "Acorda, motorista! O dia está começando e com ele, novas oportunidades. Prepare-se para uma jornada de sucesso e muitas entregas!",
          "Bom dia! Hora de acelerar em direção ao seu objetivo. Que o seu dia seja cheio de boas corridas e lucros!"
        ];
      } 
      else if (hour >= 12 && hour < 18) {
        messages = [
          "Boa tarde, motorista! O dia já está quente, mas a sua jornada ainda tem muito a oferecer. Continue firme e conquiste mais!",
          "O sol está a pino e a estrada te espera! Boa tarde, não deixe o ritmo parar. Seu sucesso está no próximo quilômetro!",
          "Boa tarde! A estrada é longa, mas a recompensa é certa. Continue focado, que a tarde é sua para aproveitar!"
        ];
      } 
      else {
        messages = [
          "Boa noite, guerreiro da estrada! O dia está acabando, mas sua força e determinação não param. Vamos fazer essa última rota valer a pena!",
          "A noite chegou, mas o trabalho não acabou! Boa noite e continue acelerando para fechar o dia com chave de ouro!",
          "Boa noite! Mesmo no fim do dia, o trabalho não para. Finalize sua jornada com energia e boa sorte na última entrega!"
        ];
      }
      
      const randomIndex = Math.floor(Math.random() * messages.length);
      return messages[randomIndex];
    };
    
    setWelcomeMessage(getTimeBasedMessage());
  }, []);

  const { data: transactions = [], isLoading: isLoadingTransactions } = useQuery({
    queryKey: ['transactions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transactions')
        .select(`
          *,
          category:transaction_categories(*)
        `)
        .order('date', { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transaction_categories')
        .select('*');
      if (error) throw error;
      return data;
    },
  });

  const totals = transactions.reduce((acc, transaction) => {
    const amount = Number(transaction.amount);
    if (transaction.type === 'income') {
      acc.income += amount;
    } else {
      acc.expenses += amount;
    }
    acc.balance = acc.income - acc.expenses;
    return acc;
  }, { income: 0, expenses: 0, balance: 0 });

  const addTransactionMutation = useMutation({
    mutationFn: async (newTransaction: {
      type: TransactionType;
      amount: number;
      category_id: string;
      description: string;
      date: string;
      user_id: string;
    }) => {
      const { data, error } = await supabase
        .from('transactions')
        .insert([newTransaction]);
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setIsAddingTransaction(false);
      setEditingTransaction(null);
    },
  });

  const updateTransactionMutation = useMutation({
    mutationFn: async (transaction: {
      id: string;
      type: TransactionType;
      amount: number;
      category_id: string;
      description: string;
      date: string;
    }) => {
      const { error } = await supabase
        .from('transactions')
        .update({
          type: transaction.type,
          amount: transaction.amount,
          category_id: transaction.category_id,
          description: transaction.description,
          date: transaction.date,
        })
        .eq('id', transaction.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setIsAddingTransaction(false);
      setEditingTransaction(null);
    },
  });

  const deleteTransactionMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('transactions')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setDeletingTransaction(null);
    },
  });

  const handleEdit = (transaction: any) => {
    setEditingTransaction(transaction);
    setIsAddingTransaction(true);
  };

  const toggleAccordion = (id: string) => {
    setActiveAccordions(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      <div className="bg-black p-4 flex justify-between items-center">
        <span className="text-primary text-lg font-semibold">RotaCerta</span>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon"
                className="text-primary hover:text-primary/80 hover:bg-transparent"
              >
                <Settings className="w-6 h-6" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-72">
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => window.open('https://site-rotacerta.netlify.app/', '_blank')}
              >
                <Users className="w-4 h-4" />
                <span>Nosso time: Pessoas incríveis por trás do nosso sucesso!</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => window.open('https://site-rotacerta.netlify.app/', '_blank')}
              >
                <Globe className="w-4 h-4" />
                <span>Explore todas as nossas ferramentas!</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => window.open('https://lgpd-rotacerta.netlify.app/', '_blank')}
              >
                <FileText className="w-4 h-4" />
                <span>Termos de uso: Simples e direto!</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon"
                className="text-primary hover:text-primary/80 hover:bg-transparent"
              >
                <Wrench className="w-6 h-6" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-72">
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => navigate('/ride-estimate')}
              >
                <Car className="w-4 h-4" />
                <span>Estimativa de Corrida (99 & Uber)</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => navigate('/food-delivery-pricing')}
              >
                <FileText className="w-4 h-4" />
                <span>Calculadora de Precificação para iFood</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => navigate('/electric-car-consumption')}
              >
                <Zap className="w-4 h-4" />
                <span>Calculadora de Consumo para Carros Elétricos</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => navigate('/tax-calculator')}
              >
                <Calculator className="w-4 h-4" />
                <span>Calculadora de Impostos</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => navigate('/charging-stations')}
              >
                <PlugZap className="w-4 h-4" />
                <span>Estações de Carregamento em SP</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                className="flex items-center gap-2 py-3 cursor-pointer"
                onClick={() => navigate('/navigation')}
              >
                <Map className="w-4 h-4" />
                <span>RotaCerta Navegação</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setShowMaintenanceTips(true)}
            className="text-primary hover:text-primary/80 hover:bg-transparent"
          >
            <Info className="w-6 h-6" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate('/vehicles')}
            className="text-primary hover:text-primary/80 hover:bg-transparent"
          >
            <Car className="w-6 h-6" />
          </Button>
        </div>
      </div>

      <AlertDialog open={showMaintenanceTips} onOpenChange={setShowMaintenanceTips}>
        <AlertDialogContent className="max-w-[95vw] sm:max-w-2xl max-h-[80vh] overflow-y-auto p-4 sm:p-6">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-center text-xl font-bold text-primary">Dicas de Manutenção</AlertDialogTitle>
          </AlertDialogHeader>
          
          <Tabs defaultValue="cars" value={activeMaintenanceTab} onValueChange={setActiveMaintenanceTab} className="mt-4">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="cars" className="flex items-center gap-2">
                <Car className="h-4 w-4" />
                <span>Carros</span>
              </TabsTrigger>
              <TabsTrigger value="motorcycles" className="flex items-center gap-2">
                <Bike className="h-4 w-4" />
                <span>Motos</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="cars" className="space-y-4 animate-fade-in">
              <div className="overflow-hidden rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[40px]"></TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead>Intervalo</TableHead>
                      <TableHead className="text-right">Importância</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('car-oil')}>
                      <TableCell>
                        <Droplet className="h-4 w-4 text-blue-500" />
                      </TableCell>
                      <TableCell className="font-medium">Óleo do motor e filtro de óleo</TableCell>
                      <TableCell>5.000 a 10.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '90%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['car-oil'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> O óleo lubrifica o motor e previne o desgaste prematuro. A troca periódica é essencial para prolongar a vida útil do motor e evitar danos graves.</p>
                            <p className="mt-2"><strong>Dica:</strong> Verifique o nível do óleo mensalmente e sempre observe o tipo de óleo recomendado pelo fabricante.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('car-air')}>
                      <TableCell>
                        <Wind className="h-4 w-4 text-gray-500" />
                      </TableCell>
                      <TableCell className="font-medium">Filtro de ar do motor</TableCell>
                      <TableCell>15.000 a 30.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: '75%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['car-air'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> O filtro de ar impede que impurezas entrem no motor, garantindo melhor desempenho e economia de combustível.</p>
                            <p className="mt-2"><strong>Dica:</strong> Em ambientes com muita poeira ou poluição, considere trocar com maior frequência.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('car-fuel')}>
                      <TableCell>
                        <Link className="h-4 w-4 text-yellow-500" />
                      </TableCell>
                      <TableCell className="font-medium">Filtro de combustível</TableCell>
                      <TableCell>20.000 a 40.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: '70%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['car-fuel'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> Responsável por filtrar impurezas do combustível antes de chegar ao motor, evitando entupimentos no sistema de injeção.</p>
                            <p className="mt-2"><strong>Dica:</strong> Sintomas de filtro entupido incluem dificuldade para dar partida e perdas de potência.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('car-spark')}>
                      <TableCell>
                        <Zap className="h-4 w-4 text-amber-500" />
                      </TableCell>
                      <TableCell className="font-medium">Velas de ignição</TableCell>
                      <TableCell>20.000 a 40.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: '80%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['car-spark'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> As velas geram a faísca necessária para a ignição da mistura ar-combustível. Seu bom funcionamento afeta diretamente o desempenho e consumo.</p>
                            <p className="mt-2"><strong>Dica:</strong> Velas desgastadas causam falhas na ignição, dificuldade na partida e aumento no consumo de combustível.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('car-belt')}>
                      <TableCell>
                        <CircleDashed className="h-4 w-4 text-purple-500" />
                      </TableCell>
                      <TableCell className="font-medium">Correia dentada</TableCell>
                      <TableCell>60.000 a 100.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '95%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['car-belt'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> A correia dentada sincroniza o movimento do virabrequim e do comando de válvulas. Seu rompimento pode causar danos graves ao motor.</p>
                            <p className="mt-2"><strong>Dica:</strong> Faça inspeções visuais periódicas para verificar sinais de desgaste e siga rigorosamente o intervalo de troca recomendado pelo fabricante.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('car-brake')}>
                      <TableCell>
                        <StopCircle className="h-4 w-4 text-red-500" />
                      </TableCell>
                      <TableCell className="font-medium">Pastilhas de freio</TableCell>
                      <TableCell>30.000 a 50.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '85%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['car-brake'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> As pastilhas são componentes fundamentais do sistema de frenagem. Seu desgaste natural precisa ser monitorado para garantir a segurança do veículo.</p>
                            <p className="mt-2"><strong>Dica:</strong> Ruídos metálicos durante a frenagem podem indicar pastilhas excessivamente desgastadas que precisam ser substituídas imediatamente.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            
            <TabsContent value="motorcycles" className="space-y-4 animate-fade-in">
              <div className="overflow-hidden rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[40px]"></TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead>Intervalo</TableHead>
                      <TableHead className="text-right">Importância</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('moto-oil')}>
                      <TableCell>
                        <Droplet className="h-4 w-4 text-blue-500" />
                      </TableCell>
                      <TableCell className="font-medium">Óleo do motor e filtro</TableCell>
                      <TableCell>3.000 a 5.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '90%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['moto-oil'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> Em motos, o óleo tem papel crucial na lubrificação, refrigeração e limpeza do motor, sendo exigido com mais frequência que em carros.</p>
                            <p className="mt-2"><strong>Dica:</strong> Use sempre o óleo de viscosidade recomendada pelo fabricante e verifique o nível semanalmente.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('moto-air')}>
                      <TableCell>
                        <Wind className="h-4 w-4 text-gray-500" />
                      </TableCell>
                      <TableCell className="font-medium">Filtro de ar</TableCell>
                      <TableCell>5.000 a 10.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: '75%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['moto-air'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> O filtro de ar em motos é especialmente importante devido à exposição direta aos elementos. Alguns modelos permitem limpeza ao invés de substituição.</p>
                            <p className="mt-2"><strong>Dica:</strong> Filtros de ar entupidos reduzem significativamente a performance da moto e aumentam o consumo.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('moto-chain')}>
                      <TableCell>
                        <Link className="h-4 w-4 text-yellow-500" />
                      </TableCell>
                      <TableCell className="font-medium">Corrente, coroa e pinhão</TableCell>
                      <TableCell>Verificação a cada 500 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '95%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['moto-chain'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> A transmissão por corrente precisa de lubrificação frequente e ajuste de tensão para prevenir desgaste prematuro e acidentes.</p>
                            <p className="mt-2"><strong>Dica:</strong> Lubrifique a corrente após andar na chuva para evitar corrosão e nunca use lubrificantes não específicos para correntes de moto.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('moto-spark')}>
                      <TableCell>
                        <Zap className="h-4 w-4 text-amber-500" />
                      </TableCell>
                      <TableCell className="font-medium">Velas de ignição</TableCell>
                      <TableCell>10.000 a 15.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-orange-500 h-2.5 rounded-full" style={{ width: '80%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['moto-spark'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> Em motos, as velas são particularmente críticas em motores de alta rotação, afetando diretamente a performance e a economia.</p>
                            <p className="mt-2"><strong>Dica:</strong> A coloração da vela pode indicar problemas no motor - velas muito escuras indicam mistura rica, enquanto velas esbranquiçadas podem indicar superaquecimento.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('moto-brake')}>
                      <TableCell>
                        <StopCircle className="h-4 w-4 text-red-500" />
                      </TableCell>
                      <TableCell className="font-medium">Pastilhas de freio</TableCell>
                      <TableCell>10.000 a 20.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '85%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['moto-brake'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> Em motos, o sistema de freios é ainda mais crítico para a segurança devido às maiores velocidades e menor estabilidade comparada aos carros.</p>
                            <p className="mt-2"><strong>Dica:</strong> Verificar o nível do fluido de freio mensalmente e substituí-lo a cada 2 anos, independente da quilometragem.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                    
                    <TableRow className="cursor-pointer hover:bg-muted/80 transition-colors" onClick={() => toggleAccordion('moto-tire')}>
                      <TableCell>
                        <Circle className="h-4 w-4 text-black" />
                      </TableCell>
                      <TableCell className="font-medium">Pneus</TableCell>
                      <TableCell>15.000 a 20.000 km</TableCell>
                      <TableCell className="text-right">
                        <div className="w-full bg-secondary rounded-full h-2.5">
                          <div className="bg-red-500 h-2.5 rounded-full" style={{ width: '95%' }}></div>
                        </div>
                      </TableCell>
                    </TableRow>
                    {activeAccordions['moto-tire'] && (
                      <TableRow className="bg-muted/30 animate-fade-in">
                        <TableCell colSpan={4} className="p-4">
                          <div className="text-sm">
                            <p><strong>Detalhes:</strong> Os pneus são fundamentais para a segurança em motos. Verifique regularmente a profundidade dos sulcos e procure por danos na carcaça.</p>
                            <p className="mt-2"><strong>Dica:</strong> Verifique a pressão dos pneus semanalmente. Pneus com pressão incorreta desgastam-se mais rápido e comprometem a segurança.</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
          
          <AlertDialogFooter className="mt-6">
            <AlertDialogAction 
              onClick={() => setShowMaintenanceTips(false)}
              className="hover-scale transition-transform duration-200"
            >
              Fechar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="p-4">
        <Card className="w-full bg-black p-4 rounded-xl mb-4 border border-black shadow-sm">
          <div className="flex items-center">
            <div className="mr-3 bg-black/20 p-2 rounded-full">
              <Car className="text-primary w-5 h-5" />
            </div>
            <p className="text-white font-medium">{welcomeMessage}</p>
          </div>
        </Card>

        <Card className="w-full bg-secondary p-4 rounded-xl mb-6">
          <h2 className="text-lg text-foreground mb-2">Saldo</h2>
          <div className="flex items-center gap-2 mb-4">
            <Wallet className="text-primary w-6 h-6" />
            <span className="text-primary text-2xl font-bold">
              R$ {totals.balance.toFixed(2)}
            </span>
          </div>
          
          <div className="flex justify-between">
            <div>
              <p className="text-foreground text-sm">Receitas</p>
              <div className="flex items-center gap-1">
                <ArrowUp className="w-4 h-4 text-green-500" />
                <span className="text-green-500">R$ {totals.income.toFixed(2)}</span>
              </div>
            </div>
            <div>
              <p className="text-foreground text-sm">Despesas</p>
              <div className="flex items-center gap-1">
                <ArrowDown className="w-4 h-4 text-red-500" />
                <span className="text-red-500">R$ {totals.expenses.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </Card>

        <h2 className="text-2xl font-bold mb-4">Transações</h2>
        <div className="space-y-3">
          {isLoadingTransactions ? (
            <p>Carregando transações...</p>
          ) : transactions.length === 0 ? (
            <p>Nenhuma transação encontrada</p>
          ) : (
            transactions.map((transaction) => (
              <Card 
                key={transaction.id}
                className="w-full bg-secondary p-4 rounded-xl flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-primary/20 p-2 rounded-full">
                    <DollarSign className="text-primary w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-medium">{transaction.category?.name}</h3>
                    <p className="text-sm text-foreground/70">{transaction.description || 'Sem descrição'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className={cn(
                      "font-medium",
                      transaction.type === "expense" ? "text-red-500" : "text-green-500"
                    )}>
                      R$ {Number(transaction.amount).toFixed(2)}
                    </p>
                    <p className="text-sm text-foreground/70">
                      {format(new Date(transaction.date), 'dd/MM/yyyy')}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(transaction)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeletingTransaction(transaction.id)}
                    >
                      <Trash className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>

      <AlertDialog open={!!deletingTransaction} onOpenChange={(open) => !open && setDeletingTransaction(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Transação</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir esta transação? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (deletingTransaction) {
                  deleteTransactionMutation.mutate(deletingTransaction);
                }
              }}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="fixed right-4 bottom-24 z-10 flex flex-col gap-4">
        <FinanceBot />
        <Sheet 
          open={isAddingTransaction} 
          onOpenChange={(open) => {
            setIsAddingTransaction(open);
            if (!open) setEditingTransaction(null);
          }}
        >
          <SheetTrigger asChild>
            <Button 
              size="icon" 
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full w-12 h-12"
            >
              <Plus className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>{editingTransaction ? 'Editar Transação' : 'Adicionar Transação'}</SheetTitle>
              <SheetDescription>
                {editingTransaction ? 'Edite sua transação' : 'Adicione uma nova receita ou despesa'}
              </SheetDescription>
            </SheetHeader>
            <form
              className="space-y-4 mt-4"
              onSubmit={async (e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) return;

                const transactionData = {
                  type: formData.get('type') as TransactionType,
                  amount: Number(formData.get('amount')),
                  category_id: formData.get('category') as string,
                  description: formData.get('description') as string,
                  date: formData.get('date') as string,
                  user_id: user.id
                };

                if (editingTransaction) {
                  updateTransactionMutation.mutate({
                    id: editingTransaction.id,
                    ...transactionData
                  });
                } else {
                  addTransactionMutation.mutate(transactionData);
                }
              }}
            >
              <div className="space-y-2">
                <Label>Tipo</Label>
                <RadioGroup 
                  name="type" 
                  className="flex gap-4" 
                  defaultValue={editingTransaction?.type || "income"}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="income" id="income" />
                    <Label htmlFor="income">Receita</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="expense" id="expense" />
                    <Label htmlFor="expense">Despesa</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Valor</Label>
                <Input
                  id="amount"
                  name="amount"
                  type="number"
                  step="0.01"
                  required
                  placeholder="0.00"
                  defaultValue={editingTransaction?.amount || ''}
                  className="[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Categoria</Label>
                <select
                  id="category"
                  name="category"
                  className="w-full rounded-md border border-input bg-background px-3 py-2"
                  required
                  defaultValue={editingTransaction?.category_id || ''}
                >
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Data</Label>
                <Input
                  id="date"
                  name="date"
                  type="date"
                  required
                  defaultValue={editingTransaction?.date || format(new Date(), 'yyyy-MM-dd')}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrição</Label>
                <Input
                  id="description"
                  name="description"
                  placeholder="Descrição da transação"
                  defaultValue={editingTransaction?.description || ''}
                />
              </div>

              <Button type="submit" className="w-full">
                {editingTransaction ? 'Salvar' : 'Adicionar'}
              </Button>
            </form>
          </SheetContent>
        </Sheet>
      </div>

      <NavBar />
    </div>
  );
};

export default Home;
