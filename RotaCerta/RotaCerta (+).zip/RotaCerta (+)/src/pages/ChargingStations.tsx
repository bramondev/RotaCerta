
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const ChargingStations = () => {
  const navigate = useNavigate();

  return (
    <div className="container pb-8">
      <div className="space-y-4 p-4">
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:text-white/80 mb-4"
          onClick={() => navigate('/home')}
        >
          <ArrowLeft className="h-6 w-6" />
        </Button>

        <Card className="bg-black text-white">
          <CardHeader>
            <CardTitle>Estações de Carregamento em SP</CardTitle>
            <CardDescription className="text-gray-400">
              As melhores estações de carregamento para veículos elétricos em São Paulo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {}
            <div className="space-y-3 pb-6 border-b border-gray-800">
              <h3 className="text-lg font-semibold text-yellow-500">São Paulo Corporate Towers</h3>
              <div className="space-y-2 text-gray-300">
                <p><span className="text-white font-medium">Localização:</span> Rua Funchal, 160 - Vila Olímpia, São Paulo</p>
                <p><span className="text-white font-medium">Equipamento:</span> Estações de recarga WEMOB modelo Parking (WEG e BeGreen)</p>
                <p><span className="text-white font-medium">Potência:</span> Total de 880 kW (22 kW por estação, configuradas para 11 kW)</p>
                <p><span className="text-white font-medium">Capacidade:</span> Até 80 veículos simultaneamente</p>
                <p><span className="text-white font-medium">Compatibilidade:</span> Todas as marcas de veículos elétricos</p>
                <p><span className="text-white font-medium">Preço:</span> Recarga gratuita + R$ 30,00 (estacionamento)</p>
              </div>
            </div>

            {/* Assaí Atacadista */}
            <div className="space-y-3 pb-6 border-b border-gray-800">
              <h3 className="text-lg font-semibold text-yellow-500">Assaí Atacadista Anhanguera</h3>
              <div className="space-y-2 text-gray-300">
                <p><span className="text-white font-medium">Localização:</span> Rua Samuel Klabin, 193 - Bela Aliança, São Paulo</p>
                <p><span className="text-white font-medium">Preço:</span> Gratuito durante compras</p>
              </div>
            </div>

            {/* Parque Trianon */}
            <div className="space-y-3 pb-6 border-b border-gray-800">
              <h3 className="text-lg font-semibold text-yellow-500">Parque Trianon</h3>
              <div className="space-y-2 text-gray-300">
                <p><span className="text-white font-medium">Localização:</span> Rua Peixoto Gomide, 949 - Cerqueira César, São Paulo</p>
                <p><span className="text-white font-medium">Equipamento:</span> Centro de recarga da Zletric e 99</p>
                <p><span className="text-white font-medium">Capacidade:</span> 7 vagas (recarga lenta) + 2 vagas (recarga rápida)</p>
                <p><span className="text-white font-medium">Tempo de Carregamento:</span></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>Lento: Até 7 horas para carga completa</li>
                  <li>Rápido: 60 minutos para carga completa</li>
                </ul>
                <p><span className="text-white font-medium">Preço:</span></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>R$ 0,99 por kWh (motoristas 99)</li>
                  <li>R$ 2,10 por kWh (demais usuários)</li>
                </ul>
              </div>
            </div>

            {/* Shell Recharge */}
            <div className="space-y-3 pb-6 border-b border-gray-800">
              <h3 className="text-lg font-semibold text-yellow-500">Shell Recharge em São Paulo</h3>
              <div className="space-y-2 text-gray-300">
                <p><span className="text-white font-medium">Localizações:</span></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>São Gualter Auto Posto - Av. São Gualter, 918, Alto de Pinheiros</li>
                  <li>Carlos Alberto Papacidero - Av. Prof. Celestino Bourroul, 34, Limão</li>
                  <li>Arinella Band Com Var Comb - Av. Dos Bandeirantes, 1365, Centro</li>
                </ul>
                <p><span className="text-white font-medium">Equipamento:</span> Carregadores DC de alta potência</p>
                <p><span className="text-white font-medium">Potência:</span> 50 a 350 kW</p>
                <p><span className="text-white font-medium">Tempo de Carregamento:</span> Até 35 minutos para recarga completa</p>
                <p><span className="text-white font-medium">Preço:</span> Variável conforme o posto</p>
              </div>
            </div>

            {/* Shopping JK Iguatemi */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-yellow-500">Shopping JK Iguatemi</h3>
              <div className="space-y-2 text-gray-300">
                <p><span className="text-white font-medium">Localização:</span> Av. Pres. Juscelino Kubitschek, 2041 - Vila Olímpia, São Paulo</p>
                <p><span className="text-white font-medium">Equipamento:</span> 2 conectores de carregamento simples</p>
                <p><span className="text-white font-medium">Preço:</span> Recarga gratuita + serviço de valet:</p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li>R$ 38,00 pela primeira hora</li>
                  <li>R$ 15,00 por hora adicional</li>
                  <li>Primeira hora gratuita para clientes Visa Platinum e Infinite</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ChargingStations;
