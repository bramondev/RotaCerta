import { useEffect, useState } from "react";
import {
  HashRouter,
  Routes,
  Route,
  Navigate,
  useNavigate,
  useLocation,
} from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { supabase } from "@/integrations/supabase/client";
import { NotificationsProvider } from "@/components/NotificationsProvider";
import Login from "./components/Login";
import Register from "./components/Register";
import Welcome from "./components/Welcome";
import Home from "./pages/Home";
import Goals from "./pages/Goals";
import Community from "./pages/Community";
import Vehicles from "./pages/Vehicles";
import Maintenance from "./pages/Maintenance";
import Statistics from "./pages/Statistics";
import AddFuel from "./pages/AddFuel";
import EditFuel from "./pages/EditFuel";
import AddDocument from "./pages/AddDocument";
import EditDocument from "./pages/EditDocument";
import NotFound from "./pages/NotFound";
import RideEstimate from "./pages/RideEstimate";
import FoodDeliveryPricing from "./pages/FoodDeliveryPricing";
import ElectricCarConsumption from "./pages/ElectricCarConsumption";
import TaxCalculator from "./pages/TaxCalculator";
import ChargingStations from "./pages/ChargingStations";
import MapNavigation from "./pages/MapNavigation";
import PasswordAdvice from "./components/PasswordAdvice";

const queryClient = new QueryClient();

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then(registration => {
        console.log('Service Worker registrado com sucesso:', registration.scope);
      })
      .catch(error => {
        console.log('Falha ao registrar o Service Worker:', error);
      });
  });
}

const setCookie = (name: string, value: string, days: number) => {
  let expires = "";
  if (days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    expires = "; expires=" + date.toUTCString();
  }
  document.cookie = name + "=" + (value || "") + expires + "; path=/";
};

const getCookie = (name: string) => {
  const nameEQ = name + "=";
  const ca = document.cookie.split(';');
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
  }
  return null;
};

const RouteTracker = () => {
  const location = useLocation();
  
  useEffect(() => {

    try {
     
      localStorage.setItem('lastRoute', location.pathname);
      
      setCookie('lastRoute', location.pathname, 30);
      
      
      localStorage.setItem('lastNavigationTime', Date.now().toString());
      setCookie('lastNavigationTime', Date.now().toString(), 30);
    } catch (e) {
      console.error("Error storing route information:", e);
    }
  }, [location]);
  
  
  useEffect(() => {
    const intervalId = setInterval(() => {
      try {
        const storedRoute = localStorage.getItem('lastRoute') || getCookie('lastRoute');
       
        if (storedRoute && storedRoute !== location.pathname) {
          console.log(`Route mismatch detected. Stored: ${storedRoute}, Current: ${location.pathname}`);
        }
      } catch (e) {
        console.error("Error in route checking:", e);
      }
    }, 5000); 
    
    return () => clearInterval(intervalId);
  }, [location]);
  
  return null;
};

const InitialRedirect = () => {
  const navigate = useNavigate();
  
  useEffect(() => {
    try {
     
      let lastRoute = localStorage.getItem('lastRoute');
      
      if (!lastRoute) {
        lastRoute = getCookie('lastRoute');
      }
      
      const lastNavTime = parseInt(localStorage.getItem('lastNavigationTime') || '0');
      const timeSinceLastNav = Date.now() - lastNavTime;
      const isColdStart = timeSinceLastNav > 3600000;
      
      console.log(`App initialization: ${isColdStart ? 'COLD START' : 'RESUME'}, Last route: ${lastRoute}`);
      
      if (lastRoute && lastRoute !== '/' && lastRoute !== '/login' && lastRoute !== '/register') {
        navigate(lastRoute);
      }
    } catch (e) {
      console.error("Error accessing storage:", e);
    }
  }, [navigate]);
  
  return null;
};

const PublicRoute = ({ children }: { children: React.ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setIsAuthenticated(!!session);
      if (session) {
        try {
          localStorage.setItem('isAuthenticated', 'true');
          setCookie('isAuthenticated', 'true', 30);
        } catch (e) {
          console.error("Error storing auth state:", e);
        }
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setIsAuthenticated(!!session);
      if (session) {
        try {
          localStorage.setItem('isAuthenticated', 'true');
          setCookie('isAuthenticated', 'true', 30);
        } catch (e) {
          console.error("Error storing auth state:", e);
        }
      } else {
        localStorage.removeItem('isAuthenticated');
        setCookie('isAuthenticated', '', -1);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  if (isAuthenticated === null) {
    return null;
  }

  return isAuthenticated ? <Navigate to="/home" replace /> : <>{children}</>;
};

const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setIsAuthenticated(!!session);
      if (session) {
        try {
          localStorage.setItem('isAuthenticated', 'true');
          setCookie('isAuthenticated', 'true', 30);
        } catch (e) {
          console.error("Error storing auth state:", e);
        }
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setIsAuthenticated(!!session);
      if (session) {
        try {
          localStorage.setItem('isAuthenticated', 'true');
          setCookie('isAuthenticated', 'true', 30);
        } catch (e) {
          console.error("Error storing auth state:", e);
        }
      } else {
        localStorage.removeItem('isAuthenticated');
        setCookie('isAuthenticated', '', -1);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  if (isAuthenticated === null) {
    try {
      const storedAuth = localStorage.getItem('isAuthenticated') === 'true' || getCookie('isAuthenticated') === 'true';
      if (storedAuth) {
        console.log("Restored auth state from storage");
        return <>{children}</>;
      }
    } catch (e) {
      console.error("Error getting stored auth state:", e);
    }
    return null;
  }

  return isAuthenticated ? <>{children}</> : <Navigate to="/" replace />;
};

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <NotificationsProvider>
        <HashRouter>
          <Toaster />
          <RouteTracker />
          <InitialRedirect />
          <Routes>
            <Route 
              path="/" 
              element={
                <PublicRoute>
                  <Welcome />
                </PublicRoute>
              } 
            />
            <Route 
              path="/password-advice" 
              element={
                <PublicRoute>
                  <PasswordAdvice />
                </PublicRoute>
              } 
            />
            <Route 
              path="/login" 
              element={
                <PublicRoute>
                  <Login />
                </PublicRoute>
              } 
            />
            <Route 
              path="/register" 
              element={
                <PublicRoute>
                  <Register />
                </PublicRoute>
              } 
            />
            <Route 
              path="/home" 
              element={
                <PrivateRoute>
                  <Home />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/goals" 
              element={
                <PrivateRoute>
                  <Goals />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/community" 
              element={
                <PrivateRoute>
                  <Community />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/vehicles" 
              element={
                <PrivateRoute>
                  <Vehicles />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/maintenance" 
              element={
                <PrivateRoute>
                  <Maintenance />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/statistics" 
              element={
                <PrivateRoute>
                  <Statistics />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/fuel/add" 
              element={
                <PrivateRoute>
                  <AddFuel />
                </PrivateRoute>
              } 
            />
            <Route
              path="/fuel/edit/:id"
              element={
                <PrivateRoute>
                  <EditFuel />
                </PrivateRoute>
              }
            />
            <Route 
              path="/documents/add" 
              element={
                <PrivateRoute>
                  <AddDocument />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/documents/edit/:id" 
              element={
                <PrivateRoute>
                  <EditDocument />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/ride-estimate" 
              element={
                <PrivateRoute>
                  <RideEstimate />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/food-delivery-pricing" 
              element={
                <PrivateRoute>
                  <FoodDeliveryPricing />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/electric-car-consumption" 
              element={
                <PrivateRoute>
                  <ElectricCarConsumption />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/tax-calculator" 
              element={
                <PrivateRoute>
                  <TaxCalculator />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/charging-stations" 
              element={
                <PrivateRoute>
                  <ChargingStations />
                </PrivateRoute>
              } 
            />
            <Route 
              path="/navigation" 
              element={
                <PrivateRoute>
                  <MapNavigation />
                </PrivateRoute>
              } 
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </HashRouter>
      </NotificationsProvider>
    </QueryClientProvider>
  );
}

export default App;
