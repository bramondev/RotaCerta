
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { NotificationsToggle } from '@/components/NotificationsToggle';
import {
  Home,
  Target,
  Users,
  Car,
  AreaChart,
  Wrench,
  LogOut,
  Calculator,
  Truck,
  Zap,
  Landmark,
  MapPin
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Sidebar({ className, ...props }: SidebarProps) {
  const location = useLocation();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Logout realizado com sucesso",
        description: "Você foi desconectado do sistema",
      });
    } catch (error) {
      toast({
        title: "Erro ao realizar logout",
        description: "Ocorreu um erro ao tentar sair do sistema",
        variant: "destructive",
      });
    }
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className={cn("pb-12 h-full flex flex-col", className)} {...props}>
      <div className="space-y-4 py-4 flex-grow">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">
            Dashboard
          </h2>
          <div className="space-y-1">
            <Button
              asChild
              variant={isActive('/home') ? 'secondary' : 'ghost'}
              className="w-full justify-start"
            >
              <Link to="/home">
                <Home className="mr-2 h-4 w-4" />
                Home
              </Link>
            </Button>
            <Button
              asChild
              variant={isActive('/goals') ? 'secondary' : 'ghost'}
              className="w-full justify-start"
            >
              <Link to="/goals">
                <Target className="mr-2 h-4 w-4" />
                Metas
              </Link>
            </Button>
            <Button
              asChild
              variant={isActive('/community') ? 'secondary' : 'ghost'}
              className="w-full justify-start"
            >
              <Link to="/community">
                <Users className="mr-2 h-4 w-4" />
                Comunidade
              </Link>
            </Button>
          </div>
        </div>
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">
            Veículos
          </h2>
          <div className="space-y-1">
            <Button
              asChild
              variant={isActive('/vehicles') ? 'secondary' : 'ghost'}
              className="w-full justify-start"
            >
              <Link to="/vehicles">
                <Car className="mr-2 h-4 w-4" />
                Meus Veículos
              </Link>
            </Button>
            <Button
              asChild
              variant={isActive('/maintenance') ? 'secondary' : 'ghost'}
              className="w-full justify-start"
            >
              <Link to="/maintenance">
                <Wrench className="mr-2 h-4 w-4" />
                Manutenção
              </Link>
            </Button>
            <Button
              asChild
              variant={isActive('/statistics') ? 'secondary' : 'ghost'}
              className="w-full justify-start"
            >
              <Link to="/statistics">
                <AreaChart className="mr-2 h-4 w-4" />
                Estatísticas
              </Link>
            </Button>
          </div>
        </div>
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">
            Ferramentas
          </h2>
          <ScrollArea className="h-[180px]">
            <div className="space-y-1">
              <Button
                asChild
                variant={isActive('/ride-estimate') ? 'secondary' : 'ghost'}
                className="w-full justify-start"
              >
                <Link to="/ride-estimate">
                  <Calculator className="mr-2 h-4 w-4" />
                  Estimativa de Corrida
                </Link>
              </Button>
              <Button
                asChild
                variant={isActive('/food-delivery-pricing') ? 'secondary' : 'ghost'}
                className="w-full justify-start"
              >
                <Link to="/food-delivery-pricing">
                  <Truck className="mr-2 h-4 w-4" />
                  Precificação de Delivery
                </Link>
              </Button>
              <Button
                asChild
                variant={isActive('/electric-car-consumption') ? 'secondary' : 'ghost'}
                className="w-full justify-start"
              >
                <Link to="/electric-car-consumption">
                  <Zap className="mr-2 h-4 w-4" />
                  Consumo de Carro Elétrico
                </Link>
              </Button>
              <Button
                asChild
                variant={isActive('/tax-calculator') ? 'secondary' : 'ghost'}
                className="w-full justify-start"
              >
                <Link to="/tax-calculator">
                  <Landmark className="mr-2 h-4 w-4" />
                  Calculadora de Impostos
                </Link>
              </Button>
              <Button
                asChild
                variant={isActive('/charging-stations') ? 'secondary' : 'ghost'}
                className="w-full justify-start"
              >
                <Link to="/charging-stations">
                  <MapPin className="mr-2 h-4 w-4" />
                  Postos de Carregamento
                </Link>
              </Button>
            </div>
          </ScrollArea>
        </div>
      </div>
      <div className="px-3 py-2 space-y-4 mt-auto">
        <div className="px-4">
          <NotificationsToggle />
        </div>
        <div>
          <Button
            variant="outline"
            className="w-full justify-start"
            onClick={handleLogout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sair
          </Button>
        </div>
      </div>
    </div>
  );
}
