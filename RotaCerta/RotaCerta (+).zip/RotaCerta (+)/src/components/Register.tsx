import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { User, Mail, Lock, Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

const Register = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const validatePassword = (password: string) => {
    const hasUpperCase = /[A-Z]/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    const hasMinLength = password.length >= 4;

    if (!hasUpperCase) {
      return "A senha deve conter pelo menos uma letra maiúscula";
    }
    if (!hasSpecialChar) {
      return "A senha deve conter pelo menos um caractere especial";
    }
    if (!hasMinLength) {
      return "A senha deve ter pelo menos 4 caracteres";
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Erro",
        description: "As senhas não coincidem",
        variant: "destructive",
      });
      return;
    }

    const passwordError = validatePassword(formData.password);
    if (passwordError) {
      toast({
        title: "Erro",
        description: passwordError,
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            name: formData.name,
          },
        },
      });

      if (error) throw error;

      toast({
        title: "Cadastro realizado!",
        description: `Enviamos um link de confirmação para ${formData.email}. Por favor, verifique sua caixa de entrada para ativar sua conta.`,
      });
      navigate("/home"); 
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center p-6">
      <div className="w-full max-w-md">
        <h1 className="text-foreground text-2xl font-bold mb-4 text-center">
          Crie sua conta para gerenciar suas entregas e finanças
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <User className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary" size={20} />
            <input
              type="text"
              placeholder="Nome"
              className="w-full bg-secondary text-foreground pl-12 pr-4 py-3 rounded-lg border border-primary/30 focus:border-primary focus:outline-none"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="relative">
            <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary" size={20} />
            <input
              type="email"
              placeholder="E-mail"
              className="w-full bg-secondary text-foreground pl-12 pr-4 py-3 rounded-lg border border-primary/30 focus:border-primary focus:outline-none"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary" size={20} />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Senha"
              className="w-full bg-secondary text-foreground pl-12 pr-12 py-3 rounded-lg border border-primary/30 focus:border-primary focus:outline-none"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-primary"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>

          <div className="relative">
            <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary" size={20} />
            <input
              type={showConfirmPassword ? "text" : "password"}
              placeholder="Confirmar senha"
              className="w-full bg-secondary text-foreground pl-12 pr-12 py-3 rounded-lg border border-primary/30 focus:border-primary focus:outline-none"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              required
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-primary"
            >
              {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>

          <button
            type="submit"
            className="w-full bg-[#FFC107] text-black font-semibold py-4 rounded-lg mt-6 disabled:opacity-50"
            disabled={loading}
          >
            {loading ? "Cadastrando..." : "Cadastrar"}
          </button>
        </form>

        <p className="text-foreground text-center mt-6">
          Já é cadastrado?{" "}
          <Link to="/login" className="text-primary font-semibold">
            Entrar
          </Link>
        </p>

        <p className="text-foreground text-sm text-center mt-8">
          Ao continuar, você concorda com nossas{" "}
          <a href="https://lgpd-rotacerta.netlify.app" target="_blank" rel="noopener noreferrer" className="text-primary">
            Políticas de privacidade
          </a>{" "}
          e{" "}
          <a href="https://lgpd-rotacerta.netlify.app" target="_blank" rel="noopener noreferrer" className="text-primary">
            Termos de uso
          </a>
        </p>
      </div>
    </div>
  );
};

export default Register;