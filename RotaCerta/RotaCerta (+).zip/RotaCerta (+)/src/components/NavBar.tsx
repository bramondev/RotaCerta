
import { useNavigate, useLocation } from "react-router-dom";
import { Wallet, Target, Car, BarChart2, Users } from "lucide-react";
import { cn } from "@/lib/utils";

const NavBar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const NavItem = ({ 
    icon, 
    label, 
    path,
    disabled = false
  }: { 
    icon: React.ReactNode; 
    label: string;
    path: string;
    disabled?: boolean;
  }) => (
    <button 
      className={cn(
        "flex flex-col items-center gap-1",
        disabled && "opacity-50 cursor-not-allowed"
      )}
      onClick={() => !disabled && navigate(path)}
      disabled={disabled}
    >
      <div className={cn(
        "p-2 rounded-lg transition-colors",
        location.pathname === path ? "text-primary" : "text-foreground/70 hover:text-primary"
      )}>
        {icon}
      </div>
      <span className={cn(
        "text-xs",
        location.pathname === path ? "text-primary" : "text-foreground/70"
      )}>
        {label}
      </span>
    </button>
  );

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-secondary p-4 border-t border-primary/20">
      <div className="flex justify-between items-center max-w-md mx-auto">
        <NavItem icon={<Wallet />} label="Finanças" path="/home" />
        <NavItem icon={<Target />} label="Metas" path="/goals" />
        <NavItem icon={<Car />} label="Manutenção" path="/maintenance" />
        <NavItem icon={<BarChart2 />} label="Estatísticas" path="/statistics" />
        <NavItem icon={<Users />} label="Comunidade" path="/community" />
      </div>
    </div>
  );
};

export default NavBar;
