
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import { Mail, Lock, Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [resetLoading, setResetLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      });

      if (error) throw error;

      toast({
        title: "Sucesso",
        description: "Login realizado com sucesso!",
      });
      navigate("/home");
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetLoading(true);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(resetEmail, {
        redirectTo: `${window.location.origin}/login`,
      });

      if (error) throw error;

      toast({
        title: "E-mail enviado",
        description: "Verifique sua caixa de entrada para redefinir sua senha.",
      });
      setShowResetDialog(false);
    } catch (error: any) {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setResetLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center p-6">
      <div className="w-full max-w-md">
        <h1 className="text-foreground text-2xl font-bold mb-8 text-center">
          Entre na sua conta
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary" size={20} />
            <input
              type="email"
              placeholder="E-mail"
              className="w-full bg-secondary text-foreground pl-12 pr-4 py-3 rounded-lg border border-primary focus:border-primary focus:outline-none"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary" size={20} />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Senha"
              className="w-full bg-secondary text-foreground pl-12 pr-12 py-3 rounded-lg border border-primary focus:border-primary focus:outline-none"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-primary"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>

          <button
            type="submit"
            className="w-full bg-[#FFC107] text-black font-semibold py-4 rounded-lg mt-6 disabled:opacity-50"
            disabled={loading}
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>

        <p className="text-foreground text-center mt-6">
          Ainda não é cadastrado?{" "}
          <Link to="/register" className="text-primary font-semibold">
            Cadastre-se
          </Link>
        </p>

        <p className="text-foreground text-sm text-center mt-8">
          Ao continuar, você concorda com nossas{" "}
          <a href="https://lgpd-rotacerta.netlify.app" target="_blank" rel="noopener noreferrer" className="text-primary">
            Políticas de privacidade
          </a>{" "}
          e{" "}
          <a href="https://lgpd-rotacerta.netlify.app" target="_blank" rel="noopener noreferrer" className="text-primary">
            Termos de uso
          </a>
        </p>
      </div>

      <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <DialogContent className="sm:max-w-md border border-primary">
          <DialogHeader>
            <DialogTitle>Recuperar senha</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleResetPassword} className="space-y-4">
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-primary" size={20} />
              <input
                type="email"
                placeholder="Digite seu e-mail"
                className="w-full bg-secondary text-foreground pl-12 pr-4 py-3 rounded-lg border border-primary focus:border-primary focus:outline-none"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-[#FFC107] text-black font-semibold py-4 rounded-lg disabled:opacity-50"
              disabled={resetLoading}
            >
              {resetLoading ? "Enviando..." : "Enviar e-mail de recuperação"}
            </button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Login;
