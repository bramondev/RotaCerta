
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { format, parse } from "date-fns";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const maintenanceCategories = [
  { value: "corrective", label: "Manutenção Corretiva" },
  { value: "preventive", label: "Manutenção Preventiva" },
] as const;

const maintenanceSubtypes = {
  corrective: [
    { value: "emergency_corrective", label: "Corretiva Emergencial" },
    { value: "planned_corrective", label: "Corretiva Planejada" },
    { value: "predictive_corrective", label: "Corretiva Preditiva" },
  ],
  preventive: [
    { value: "scheduled_preventive", label: "Preventiva Programada" },
    { value: "condition_based_preventive", label: "Preventiva Baseada em Condição" },
    { value: "proactive_preventive", label: "Preventiva Proativa" },
  ],
} as const;

const formSchema = z.object({
  vehicleId: z.string({
    required_error: "Selecione um veículo",
  }),
  category: z.enum(["corrective", "preventive"], {
    required_error: "Selecione a categoria de manutenção",
  }),
  subtype: z.enum([
    "emergency_corrective",
    "planned_corrective",
    "predictive_corrective",
    "scheduled_preventive",
    "condition_based_preventive",
    "proactive_preventive"
  ], {
    required_error: "Selecione o tipo de manutenção",
  }),
  description: z.string().optional(),
  cost: z.string().min(1, "Informe o custo"),
  mileage: z.string().min(1, "Informe a quilometragem"),
  date: z.string().min(1, "Informe a data").refine((date) => {
    try {
      parse(date, "dd/MM/yyyy", new Date());
      return true;
    } catch {
      return false;
    }
  }, "Data inválida. Use o formato dd/mm/aaaa"),
  isFuture: z.enum(["yes", "no"], {
    required_error: "Selecione se é uma manutenção futura",
  }).default("no"),
});

export function MaintenanceForm({
  onClose,
  maintenance,
}: {
  onClose: () => void;
  maintenance?: any;
}) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: vehicles } = useQuery({
    queryKey: ["vehicles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("vehicles")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: maintenance
      ? {
          vehicleId: maintenance.vehicle_id,
          category: maintenance.category,
          subtype: maintenance.subtype,
          description: maintenance.description || "",
          cost: maintenance.cost.toString(),
          mileage: maintenance.mileage.toString(),
          date: format(new Date(maintenance.date), "dd/MM/yyyy"),
          isFuture: maintenance.is_future ? "yes" : "no",
        }
      : {
          isFuture: "no",
        },
  });

  // Observar a categoria selecionada para atualizar os subtipos disponíveis
  const selectedCategory = form.watch("category");

  async function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError || !user) {
        throw new Error("Usuário não autenticado");
      }

      // Parse the date from dd/MM/yyyy to yyyy-MM-dd
      const parsedDate = parse(values.date, "dd/MM/yyyy", new Date());
      const formattedDate = format(parsedDate, "yyyy-MM-dd");

      const maintenanceData = {
        vehicle_id: values.vehicleId,
        user_id: user.id,
        category: values.category,
        subtype: values.subtype,
        description: values.description,
        cost: parseFloat(values.cost),
        mileage: parseInt(values.mileage),
        date: formattedDate,
        is_future: values.isFuture === "yes",
      };

      const { error } = maintenance
        ? await supabase
            .from("maintenance")
            .update(maintenanceData)
            .eq("id", maintenance.id)
        : await supabase.from("maintenance").insert(maintenanceData);

      if (error) {
        console.error("Erro do Supabase:", error);
        throw error;
      }

      toast({
        title: `Manutenção ${maintenance ? "atualizada" : "registrada"} com sucesso!`,
      });
      
      queryClient.invalidateQueries({ queryKey: ["maintenance"] });
      onClose();
    } catch (error) {
      console.error("Erro ao salvar manutenção:", error);
      toast({
        variant: "destructive",
        title: "Erro ao salvar manutenção",
        description: "Tente novamente mais tarde",
      });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="vehicleId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Veículo</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um veículo" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {vehicles?.map((vehicle) => (
                    <SelectItem key={vehicle.id} value={vehicle.id}>
                      {vehicle.model} - {vehicle.plate}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="category"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Categoria de Manutenção</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a categoria" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {maintenanceCategories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="subtype"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tipo de Manutenção</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {selectedCategory && maintenanceSubtypes[selectedCategory].map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="isFuture"
          render={({ field }) => (
            <FormItem className="space-y-3">
              <FormLabel>Tipo de Registro</FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                  className="flex flex-col space-y-1"
                >
                  <FormItem className="flex items-center space-x-3 space-y-0">
                    <FormControl>
                      <RadioGroupItem value="no" />
                    </FormControl>
                    <FormLabel className="font-normal">
                      Manutenção Realizada
                    </FormLabel>
                  </FormItem>
                  <FormItem className="flex items-center space-x-3 space-y-0">
                    <FormControl>
                      <RadioGroupItem value="yes" />
                    </FormControl>
                    <FormLabel className="font-normal">
                      Manutenção Futura
                    </FormLabel>
                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormDescription>
                Selecione se esta é uma manutenção já realizada ou uma manutenção futura programada.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Descrição (opcional)</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Detalhes da manutenção..."
                  className="resize-none"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="cost"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Custo</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  className="[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="mileage"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Quilometragem</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  placeholder="0"
                  className="[appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="date"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Data</FormLabel>
              <FormControl>
                <Input
                  placeholder="dd/mm/aaaa"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex gap-4">
          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={onClose}
          >
            Cancelar
          </Button>
          <Button type="submit" className="w-full">
            {maintenance ? "Atualizar" : "Salvar"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
