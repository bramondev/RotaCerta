import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { MaintenanceForm } from "./MaintenanceForm";

export function MaintenanceDialog({
  open,
  onOpenChange,
  maintenance,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  maintenance?: any;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[400px] p-4 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {maintenance ? "Editar Manutenção" : "Nova Manutenção"}
          </DialogTitle>
        </DialogHeader>
        <MaintenanceForm
          onClose={() => onOpenChange(false)}
          maintenance={maintenance}
        />
      </DialogContent>
    </Dialog>
  );
}